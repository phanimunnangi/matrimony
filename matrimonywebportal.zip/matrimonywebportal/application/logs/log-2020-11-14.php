<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-14 03:00:21 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-14 03:00:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-14 07:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-14 07:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-14 08:49:14 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-14 08:49:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-14 17:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-14 18:46:07 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-14 18:46:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-14 23:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-14 23:11:48 --> 404 Page Not Found: Business/index
ERROR - 2020-11-14 23:42:58 --> 404 Page Not Found: Robotstxt/index

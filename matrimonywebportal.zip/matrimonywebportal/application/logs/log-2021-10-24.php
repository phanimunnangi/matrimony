<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-24 12:14:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-24 12:15:04 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2021-10-24 12:15:04 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2021-10-24 12:16:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-24 12:16:38 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-24 13:23:35 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2021-10-24 13:23:40 --> 404 Page Not Found: Servicepics/Mob_14102020143947users-icon.png
ERROR - 2021-10-24 13:23:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-24 15:24:15 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2021-10-24 15:24:34 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2021-10-24 15:24:34 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2021-10-24 15:24:38 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2021-10-24 15:24:42 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2021-10-24 15:24:44 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2021-10-24 15:24:48 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2021-10-24 15:24:51 --> 404 Page Not Found: admin/Settings/skin-config.html

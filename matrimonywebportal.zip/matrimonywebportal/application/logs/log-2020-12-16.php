<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-16 05:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-16 05:36:05 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-12-16 05:36:05 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-12-16 05:37:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-16 05:37:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-16 06:28:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-16 06:28:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-16 06:38:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-16 06:38:21 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-12-16 06:38:21 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-12-16 06:43:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-16 06:43:38 --> 404 Page Not Found: admin//index
ERROR - 2020-12-16 06:43:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-16 06:44:11 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-12-16 06:44:11 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-12-16 06:44:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-16 06:44:36 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-16 06:44:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-16 09:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-16 11:28:16 --> 404 Page Not Found: Faviconico/index

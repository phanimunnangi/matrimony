<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-03 00:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-03 03:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-03 16:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-03 16:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-03 18:28:49 --> 404 Page Not Found: Faviconico/index

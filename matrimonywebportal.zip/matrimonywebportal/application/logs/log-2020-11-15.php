<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-15 03:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-15 04:43:18 --> 404 Page Not Found: Business/index
ERROR - 2020-11-15 12:15:07 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-15 12:15:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-15 20:17:58 --> 404 Page Not Found: Business/index

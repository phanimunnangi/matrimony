<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-19 18:50:13 --> 404 Page Not Found: admin/Skin-confightml/index
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-19 18:50:13 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index

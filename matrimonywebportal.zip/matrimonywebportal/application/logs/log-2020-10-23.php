<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-23 15:30:13 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-23 15:30:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-23 15:34:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-23 17:44:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-23 17:44:36 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-23 17:44:36 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-23 17:44:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-23 17:44:43 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-23 17:50:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-23 17:50:09 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-23 17:50:09 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-23 17:50:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-23 18:18:19 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-23 18:18:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-23 22:13:19 --> Severity: Warning --> mysqli::query(): Empty query /home2/matrimonyapp/public_html/demo/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2020-10-23 22:13:19 --> Query error:  - Invalid query: 
ERROR - 2020-10-23 22:13:19 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-23 22:13:23 --> Severity: Warning --> mysqli::query(): Empty query /home2/matrimonyapp/public_html/demo/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2020-10-23 22:13:23 --> Query error:  - Invalid query: 
ERROR - 2020-10-23 22:13:23 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-23 22:13:29 --> Severity: Warning --> mysqli::query(): Empty query /home2/matrimonyapp/public_html/demo/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2020-10-23 22:13:29 --> Query error:  - Invalid query: 
ERROR - 2020-10-23 22:13:29 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-23 22:13:35 --> Severity: Warning --> mysqli::query(): Empty query /home2/matrimonyapp/public_html/demo/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2020-10-23 22:13:35 --> Query error:  - Invalid query: 
ERROR - 2020-10-23 22:13:35 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254

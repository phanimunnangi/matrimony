<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-08 09:04:58 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-08 09:05:36 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-08 10:03:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-08 10:05:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-08 20:19:39 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-08 20:19:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-08 20:19:52 --> 404 Page Not Found: admin/Common/skin-config.html

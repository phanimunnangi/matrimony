<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-13 05:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-13 10:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-13 13:05:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-13 13:05:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:05:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:05:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 13:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:05:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 13:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:05:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:05:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:05:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 13:05:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:05:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 13:07:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 13:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 13:07:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:07:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:11:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 13:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:12:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 13:12:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:12:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:12:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:12:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:23:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 13:23:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 13:23:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-13 15:54:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:54:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:54:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 15:54:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:54:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:55:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 15:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 15:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 15:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 18:11:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-13 19:32:19 --> 404 Page Not Found: admin/Env/index
ERROR - 2020-12-13 21:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-13 23:34:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-13 23:34:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 23:34:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 23:34:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 23:34:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-13 23:52:27 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 72
ERROR - 2020-12-13 23:53:36 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 72
ERROR - 2020-12-13 23:54:26 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 73
ERROR - 2020-12-13 23:55:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 73
ERROR - 2020-12-13 23:58:24 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 73
ERROR - 2020-12-13 23:58:49 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 73

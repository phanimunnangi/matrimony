<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-16 00:55:20 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-16 00:55:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-16 00:55:58 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-16 00:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-16 01:51:15 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-16 01:51:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-16 02:11:29 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-16 02:11:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-16 02:13:22 --> 404 Page Not Found: Business/index
ERROR - 2020-11-16 02:14:44 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-16 02:14:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-16 05:08:33 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-16 05:08:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-16 07:09:11 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-16 07:09:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-16 07:55:33 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-11-16 07:55:35 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-11-16 07:55:35 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-11-16 07:55:36 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-11-16 07:55:36 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-11-16 07:55:36 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-11-16 07:55:37 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-11-16 07:55:37 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-11-16 07:55:37 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-11-16 07:55:38 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-11-16 07:55:38 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2020-11-16 07:55:38 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-11-16 07:55:39 --> 404 Page Not Found: Media/wp-includes
ERROR - 2020-11-16 07:55:39 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-11-16 07:55:39 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-11-16 07:55:40 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-11-16 07:55:40 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2020-11-16 13:03:59 --> 404 Page Not Found: Robotstxt/index

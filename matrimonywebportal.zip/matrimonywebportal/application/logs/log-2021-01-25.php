<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-25 12:15:27 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) D:\xampp\htdocs\matrimonywebportal\application\views\includes\header.php 104
ERROR - 2021-01-25 12:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 12:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 12:39:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-25 12:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 12:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 12:39:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-25 12:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 12:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:43:22 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:43:22 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:43:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-25 16:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:47:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-25 16:48:16 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:48:16 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:48:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-25 16:48:16 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:48:16 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:48:31 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:48:31 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:48:31 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:48:31 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:48:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-25 16:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:49:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-25 16:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:49:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-25 16:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 16:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 17:01:37 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 17:01:37 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-25 17:01:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-25 20:31:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= ''
WHERE `fmid` IS NULL' at line 1 - Invalid query: UPDATE `ma_family_members` SET  = ''
WHERE `fmid` IS NULL
ERROR - 2021-01-25 20:33:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= ''
WHERE `fmid` = '1'' at line 1 - Invalid query: UPDATE `ma_family_members` SET  = ''
WHERE `fmid` = '1'
ERROR - 2021-01-25 20:35:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= ''
WHERE `fmid` = '1'' at line 1 - Invalid query: UPDATE `ma_family_members` SET  = ''
WHERE `fmid` = '1'
ERROR - 2021-01-25 20:37:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= ''
WHERE `fmid` = '1'' at line 1 - Invalid query: UPDATE `ma_family_members` SET  = ''
WHERE `fmid` = '1'
ERROR - 2021-01-25 20:38:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= ''
WHERE `fmid` = '1'' at line 1 - Invalid query: UPDATE `ma_family_members` SET  = ''
WHERE `fmid` = '1'
ERROR - 2021-01-25 20:39:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= ''
WHERE `fmid` = '1'' at line 1 - Invalid query: UPDATE `ma_family_members` SET  = ''
WHERE `fmid` = '1'

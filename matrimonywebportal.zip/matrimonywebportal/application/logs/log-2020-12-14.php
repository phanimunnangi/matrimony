<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-14 00:01:36 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 74
ERROR - 2020-12-14 00:02:22 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 75
ERROR - 2020-12-14 00:02:43 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 102
ERROR - 2020-12-14 00:03:35 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 102
ERROR - 2020-12-14 00:04:37 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 102
ERROR - 2020-12-14 00:05:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 105
ERROR - 2020-12-14 00:05:32 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 105
ERROR - 2020-12-14 00:06:04 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 105
ERROR - 2020-12-14 00:11:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php 72
ERROR - 2020-12-14 00:14:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php:14) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-12-14 00:16:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/application/controllers/LoaddingPage.php:14) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-12-14 00:18:19 --> 404 Page Not Found: Fmember-collections/index
ERROR - 2020-12-14 00:26:26 --> 404 Page Not Found: Family-member/index
ERROR - 2020-12-14 00:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 00:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 00:27:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 00:32:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-14 00:33:07 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-12-14 00:33:07 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-12-14 00:33:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 00:36:01 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/nayeebrahmincomm/public_html/application/controllers/admin/Common.php 282
ERROR - 2020-12-14 00:36:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 00:37:10 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting variable (T_VARIABLE) or '$' /home2/nayeebrahmincomm/public_html/application/controllers/admin/Common.php 876
ERROR - 2020-12-14 00:37:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 00:38:24 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 00:38:47 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 00:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-14 00:44:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 00:59:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 04:31:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 06:22:41 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2020-12-14 08:09:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 08:10:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-14 08:10:43 --> 404 Page Not Found: admin/Familymembers/index
ERROR - 2020-12-14 08:10:57 --> 404 Page Not Found: admin/Familymembers/index
ERROR - 2020-12-14 08:11:15 --> 404 Page Not Found: admin/Familymembers/index
ERROR - 2020-12-14 08:11:17 --> 404 Page Not Found: admin/Familymembers/index
ERROR - 2020-12-14 08:11:47 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-12-14 08:11:48 --> 404 Page Not Found: admin/Familymembers/index
ERROR - 2020-12-14 08:11:56 --> 404 Page Not Found: admin/Family-members/index
ERROR - 2020-12-14 08:12:08 --> 404 Page Not Found: admin/Familymembers/index
ERROR - 2020-12-14 08:12:15 --> 404 Page Not Found: admin/Family-collections/index
ERROR - 2020-12-14 08:15:00 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-12-14 08:15:00 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-12-14 08:15:36 --> 404 Page Not Found: admin/Familymembers/index
ERROR - 2020-12-14 08:15:55 --> 404 Page Not Found: admin/Familymembers/index
ERROR - 2020-12-14 08:16:54 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-12-14 08:17:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:17:05 --> 404 Page Not Found: Servicepics/Mob_14102020143947users-icon.png
ERROR - 2020-12-14 08:17:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:17:09 --> 404 Page Not Found: Userservicepics/Mob_11102020174036ps-img1.png
ERROR - 2020-12-14 08:17:09 --> 404 Page Not Found: Userservicepics/Mob_01102020200414ps-img1.png
ERROR - 2020-12-14 08:17:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:17:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:19:43 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 63
ERROR - 2020-12-14 08:19:44 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 63
ERROR - 2020-12-14 08:19:46 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 63
ERROR - 2020-12-14 08:19:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:20:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:22:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:23:42 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:23:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:24:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:25:33 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:25:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:25:42 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:27:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:27:51 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:28:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:29:32 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:30:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:30:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:39:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 08:39:27 --> Query error: Unknown column 'profile_status' in 'where clause' - Invalid query: SELECT *
FROM `ma_family_members_bloods`
WHERE `profile_status` != 2
AND `profile_parentid` = '1'
ORDER BY `pmmid` DESC
ERROR - 2020-12-14 08:39:27 --> Severity: Error --> Call to a member function result() on a non-object /home2/nayeebrahmincomm/public_html/application/models/admin/Common_model.php 55
ERROR - 2020-12-14 08:39:31 --> Query error: Unknown column 'profile_status' in 'where clause' - Invalid query: SELECT *
FROM `ma_family_members_bloods`
WHERE `profile_status` != 2
AND `profile_parentid` = '1'
ORDER BY `pmmid` DESC
ERROR - 2020-12-14 08:39:31 --> Severity: Error --> Call to a member function result() on a non-object /home2/nayeebrahmincomm/public_html/application/models/admin/Common_model.php 55
ERROR - 2020-12-14 08:40:35 --> Query error: Unknown column 'profile_status' in 'where clause' - Invalid query: SELECT *
FROM `ma_family_members_bloods`
WHERE `profile_status` != 2
AND `profile_parentid` = '1'
ORDER BY `pmmid` DESC
ERROR - 2020-12-14 08:40:35 --> Severity: Error --> Call to a member function result() on a non-object /home2/nayeebrahmincomm/public_html/application/models/admin/Common_model.php 55
ERROR - 2020-12-14 09:09:05 --> Query error: Unknown column 'profile_status' in 'where clause' - Invalid query: select * from ma_family_members_bloods where profile_parentid = 1 and profile_status != 2 ORDER BY pmmid DESC
ERROR - 2020-12-14 09:09:05 --> Severity: Error --> Call to a member function result() on a non-object /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 42
ERROR - 2020-12-14 09:09:08 --> Query error: Unknown column 'profile_status' in 'where clause' - Invalid query: select * from ma_family_members_bloods where profile_parentid = 1 and profile_status != 2 ORDER BY pmmid DESC
ERROR - 2020-12-14 09:09:08 --> Severity: Error --> Call to a member function result() on a non-object /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 42
ERROR - 2020-12-14 09:10:28 --> Query error: Unknown column 'profile_status' in 'where clause' - Invalid query: select * from ma_family_members_bloods where profile_parentid = 1 and profile_status != 2 ORDER BY pmmid DESC
ERROR - 2020-12-14 09:10:28 --> Severity: Error --> Call to a member function result() on a non-object /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 42
ERROR - 2020-12-14 09:10:33 --> Query error: Unknown column 'profile_status' in 'where clause' - Invalid query: select * from ma_family_members_bloods where profile_parentid = 1 and profile_status != 2 ORDER BY pmmid DESC
ERROR - 2020-12-14 09:10:33 --> Severity: Error --> Call to a member function result() on a non-object /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 42
ERROR - 2020-12-14 09:11:26 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$user_registeredid /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 78
ERROR - 2020-12-14 09:20:01 --> Severity: Notice --> Undefined property: stdClass::$user_registeredid /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 78
ERROR - 2020-12-14 09:20:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:20:22 --> Query error: Unknown column 'profile_status' in 'where clause' - Invalid query: select * from ma_family_members_bloods where profile_parentid = 1 and profile_status != 2 ORDER BY pmmid DESC
ERROR - 2020-12-14 09:20:22 --> Severity: Error --> Call to a member function result() on a non-object /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 45
ERROR - 2020-12-14 09:21:48 --> Severity: Notice --> Undefined property: stdClass::$user_registeredid /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 78
ERROR - 2020-12-14 09:21:48 --> Severity: Notice --> Undefined property: stdClass::$user_registeredid /home2/nayeebrahmincomm/public_html/application/views/admin/familymembers.php 78
ERROR - 2020-12-14 09:21:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:22:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:26:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:26:33 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:26:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:27:29 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:29:48 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:30:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 09:31:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 11:12:59 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 11:19:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 11:27:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:27:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:27:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 11:27:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 11:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:27:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 11:27:56 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-12-14 11:27:59 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 11:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:54:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 11:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:54:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 11:54:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:54:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:54:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:54:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:57:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:57:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:57:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 11:57:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:57:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:57:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 11:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:58:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 11:58:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:58:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:58:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 11:58:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:06:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:06:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:06:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 12:09:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:09:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 12:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:09:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 12:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:09:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 12:17:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:17:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:17:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 12:22:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:22:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:22:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 12:22:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:22:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:22:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 12:22:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:22:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:22:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 12:43:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 12:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:45:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 12:46:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-14 12:46:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:46:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:46:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:46:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-14 12:50:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 13:07:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 13:49:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 15:04:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 15:05:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-14 15:05:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 15:06:53 --> 404 Page Not Found: Toastrjsmap/index
ERROR - 2020-12-14 15:06:57 --> 404 Page Not Found: Toastrjsmap/index
ERROR - 2020-12-14 15:06:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-14 15:11:41 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-12-14 15:11:41 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-12-14 15:11:56 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 15:12:03 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 15:34:29 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 15:35:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 15:35:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-14 15:37:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 15:38:36 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 15:51:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-12-14 19:37:33 --> 404 Page Not Found: Robotstxt/index

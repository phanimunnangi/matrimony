<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-05 01:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-05 02:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-05 03:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-05 03:51:25 --> 404 Page Not Found: Uploads/members
ERROR - 2020-12-05 13:48:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-05 14:53:44 --> 404 Page Not Found: Old/index
ERROR - 2020-12-05 14:56:26 --> 404 Page Not Found: Images/logo-nbc.png
ERROR - 2020-12-05 14:56:26 --> 404 Page Not Found: Uploads/members
ERROR - 2020-12-05 14:56:26 --> 404 Page Not Found: Uploads/members
ERROR - 2020-12-05 14:56:26 --> 404 Page Not Found: Uploads/members
ERROR - 2020-12-05 14:56:29 --> 404 Page Not Found: Member/matrimony_register
ERROR - 2020-12-05 15:15:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-05 20:34:36 --> 404 Page Not Found: Robotstxt/index

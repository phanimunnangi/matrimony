<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-07 09:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-07 11:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-07 15:28:21 --> 404 Page Not Found: Robotstxt/index

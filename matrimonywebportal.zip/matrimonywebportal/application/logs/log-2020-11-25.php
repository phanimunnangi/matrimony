<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-25 09:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-25 09:34:16 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2020-11-25 09:34:16 --> 404 Page Not Found: Ftpconfig/index
ERROR - 2020-11-25 09:34:16 --> 404 Page Not Found: Remote-syncjson/index
ERROR - 2020-11-25 09:34:17 --> 404 Page Not Found: Vscode/ftp-sync.json
ERROR - 2020-11-25 09:34:17 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2020-11-25 09:34:17 --> 404 Page Not Found: Deployment-configjson/index
ERROR - 2020-11-25 09:34:17 --> 404 Page Not Found: Ftpsyncsettings/index
ERROR - 2020-11-25 09:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-25 13:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-25 18:25:13 --> 404 Page Not Found: Robotstxt/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-18 01:28:37 --> 404 Page Not Found: Uploads/members

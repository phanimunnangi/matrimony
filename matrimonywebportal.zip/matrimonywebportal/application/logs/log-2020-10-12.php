<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-12 03:07:32 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-12 03:23:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:24:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:24:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:27:20 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:28:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:28:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:28:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:29:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:29:03 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 03:29:03 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 03:29:36 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 03:29:36 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:29:36 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 03:29:42 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:30:03 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:30:07 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 03:30:07 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 03:30:42 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 03:30:42 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:30:42 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 03:43:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:44:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:53:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:54:27 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:54:44 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 03:54:44 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 03:54:52 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 03:54:52 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 03:55:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 03:55:11 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 03:55:12 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:02:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:03:27 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:03:28 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:03:40 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:03:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:03:41 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:18:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:20:26 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:22:35 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:22:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:22:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-12 04:22:50 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-12 04:23:56 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:24:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:24:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:24:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:24:36 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:26:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:26:18 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:26:19 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:27:04 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:27:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:27:04 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:28:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:28:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:36:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:37:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:38:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:38:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:38:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:38:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:39:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:39:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:39:20 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:39:20 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:39:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:39:47 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:39:47 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:40:28 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:40:28 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:40:28 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:43:20 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:43:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:44:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:44:59 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:45:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:45:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:46:48 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:47:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:48:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:48:40 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:48:41 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:49:53 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:49:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:49:54 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:50:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:50:11 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:50:11 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:50:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:50:21 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:50:21 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:50:27 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:50:27 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:50:27 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:51:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:51:16 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:51:16 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:53:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:53:01 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:53:01 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 04:54:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 04:54:42 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 04:54:42 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 05:06:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 05:06:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 05:06:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 05:39:36 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 05:39:36 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:39:36 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 05:41:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:41:19 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 05:41:19 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 05:42:24 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:42:24 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 05:42:25 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 05:44:56 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 05:44:56 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:44:56 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 05:45:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:45:11 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 05:45:11 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 05:47:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:47:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:47:26 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:47:28 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:51:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:51:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:52:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:52:31 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:52:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:53:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:53:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:53:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:53:42 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:53:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:54:38 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:54:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:54:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:55:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:57:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 05:57:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:06:49 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 1460
ERROR - 2020-10-12 06:06:51 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 1460
ERROR - 2020-10-12 06:07:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:07:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:08:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:12:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 06:12:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 06:12:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 06:13:07 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:13:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:13:07 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:14:01 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:14:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:14:01 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:14:02 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:14:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:14:02 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:15:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:15:46 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:15:46 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:19:58 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:19:59 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:19:59 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:20:21 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:20:21 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:20:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:20:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-12 06:20:22 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-12 06:20:22 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:20:22 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:20:29 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:20:29 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:20:29 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:21:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:21:16 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:21:16 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:21:29 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:21:29 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:21:29 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:21:30 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:21:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-12 06:21:30 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-12 06:21:30 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:21:31 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:22:18 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:22:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:22:19 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:22:38 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:22:38 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:22:38 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:22:42 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:22:42 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:22:42 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:23:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:23:17 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:23:17 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:23:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:23:19 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:23:19 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:23:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:23:37 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:23:37 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:23:43 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:23:43 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:23:43 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:23:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-12 06:23:44 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-12 06:24:09 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 06:24:09 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:24:09 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 06:24:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-12 06:24:09 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-12 06:24:26 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:24:30 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:25:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:26:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:29:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:43:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:44:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:48:31 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:50:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:57:43 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:57:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:57:48 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:57:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:57:51 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:58:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:58:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:58:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 06:58:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:07:48 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:07:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:07:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:09:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:09:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:12:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:15:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:15:42 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:15:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:15:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:15:48 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:15:51 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:16:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:16:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:16:27 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:16:31 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:16:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:18:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:19:03 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:20:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:20:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:20:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:20:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:20:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:20:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:21:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:21:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:21:03 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:21:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:22:56 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:22:58 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:22:59 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:23:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:23:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:23:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:23:09 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:23:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:24:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:24:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:24:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:24:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:24:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:25:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:25:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:25:56 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 07:26:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:17:43 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:18:58 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:18:58 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-12 08:18:58 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-12 08:39:39 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-12 08:39:41 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-12 08:39:42 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-12 08:39:43 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-12 08:39:43 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-12 08:39:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:39:48 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:39:51 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:39:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:39:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:39:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:39:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:40:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:41:35 --> 404 Page Not Found: Groom-profiles/index
ERROR - 2020-10-12 08:45:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:45:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:45:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 08:49:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 08:49:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:49:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:54:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 08:54:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:54:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 08:55:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:55:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:56:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 08:56:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:56:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:57:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:57:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:57:43 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:57:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:57:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:57:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:32 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:35 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:43 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:58:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:59:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 08:59:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 08:59:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 08:59:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:00:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 09:00:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:00:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:04:28 --> Severity: error --> Exception: Too few arguments to function Common_model::get_data_equal_multiple_columns_records(), 7 passed in D:\xampp\htdocs\matrimonyapp\application\controllers\LoaddingPage.php on line 17 and exactly 9 expected D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 70
ERROR - 2020-10-12 09:11:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 09:11:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:11:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:15:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 09:15:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:15:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:24:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\index.php 188
ERROR - 2020-10-12 09:24:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 09:24:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:24:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:28:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\index.php 188
ERROR - 2020-10-12 09:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 09:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:33:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\index.php 188
ERROR - 2020-10-12 09:33:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 09:33:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:33:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:34:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 09:34:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:34:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:35:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 09:35:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 09:35:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:02:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-12 10:40:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:40:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:40:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:41:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:41:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:41:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:42:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:42:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:42:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:42:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:43:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:43:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:43:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:44:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:44:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:44:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:45:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:45:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:47:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:47:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:47:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:48:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:48:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:48:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:49:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:49:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:49:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:50:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:50:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:50:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:52:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:52:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:52:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:54:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:54:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:54:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:55:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:55:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:55:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:55:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:55:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:55:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:56:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 10:56:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 10:56:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 11:12:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 11:12:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 11:12:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 11:19:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 11:19:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 11:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 11:37:36 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 183
ERROR - 2020-10-12 13:14:58 --> Severity: error --> Exception: syntax error, unexpected '$stt' (T_VARIABLE), expecting ',' or ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 179
ERROR - 2020-10-12 13:37:29 --> Severity: error --> Exception: syntax error, unexpected '$stt' (T_VARIABLE), expecting ',' or ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 180
ERROR - 2020-10-12 13:38:09 --> Severity: error --> Exception: syntax error, unexpected '$stt' (T_VARIABLE), expecting ',' or ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 180
ERROR - 2020-10-12 13:38:47 --> Severity: error --> Exception: syntax error, unexpected '$stt' (T_VARIABLE), expecting ',' or ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 180
ERROR - 2020-10-12 13:40:49 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 184
ERROR - 2020-10-12 13:41:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma' at line 2 - Invalid query: SELECT *
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
WHERE `user_is_featured` = 1
AND `user_is_nri` = 1
AND `user_status` = 1
ORDER BY RAND()
 LIMIT 10
ERROR - 2020-10-12 13:41:15 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 187
ERROR - 2020-10-12 13:41:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma' at line 2 - Invalid query: SELECT *
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
WHERE `user_is_featured` = 1
AND `user_is_nri` = 1
AND `user_status` = 1
ORDER BY RAND()
 LIMIT 10
ERROR - 2020-10-12 13:41:16 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 187
ERROR - 2020-10-12 13:41:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma' at line 2 - Invalid query: SELECT *
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
ORDER BY RAND()
 LIMIT 10
ERROR - 2020-10-12 13:41:27 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 187
ERROR - 2020-10-12 13:41:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma' at line 2 - Invalid query: SELECT *
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
ORDER BY RAND()
 LIMIT 10
ERROR - 2020-10-12 13:41:28 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 187
ERROR - 2020-10-12 13:45:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma' at line 2 - Invalid query: SELECT *
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
WHERE `user_is_featured` = 1
AND `user_is_nri` = 1
AND `user_status` = 1
ORDER BY RAND()
 LIMIT 10
ERROR - 2020-10-12 13:45:52 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 187
ERROR - 2020-10-12 13:46:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma' at line 2 - Invalid query: SELECT *
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
WHERE `user_status` = 1
ORDER BY RAND()
 LIMIT 10
ERROR - 2020-10-12 13:46:02 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 187
ERROR - 2020-10-12 13:47:23 --> Severity: Notice --> Undefined variable: table D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 190
ERROR - 2020-10-12 13:47:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma' at line 2 - Invalid query: SELECT *
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
WHERE `user_status` = 1
ORDER BY RAND()
 LIMIT 10
ERROR - 2020-10-12 13:47:23 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 190
ERROR - 2020-10-12 13:48:53 --> Query error: Unknown column 'male' in 'where clause' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
WHERE `user_is_featured` = 1
AND `user_gender` = `male`
AND `user_status` = 1
ORDER BY RAND()
 LIMIT 10
ERROR - 2020-10-12 13:48:53 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 190
ERROR - 2020-10-12 14:13:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:13:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:13:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:23:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:24:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:27:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:27:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:27:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:29:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:29:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:29:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:29:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:29:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:29:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:30:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:30:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:30:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:30:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:30:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:30:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:30:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:30:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:30:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:31:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:31:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:31:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:32:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:32:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:32:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:32:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:33:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:33:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:33:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:33:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:33:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:33:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:33:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:35:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:35:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:35:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:36:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:36:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:36:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:36:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:36:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:36:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:37:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:38:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:38:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:38:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:38:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:38:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:38:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:38:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:38:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:38:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:40:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:40:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:41:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:41:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:41:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:41:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:41:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:41:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:43:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:44:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:44:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:44:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:45:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:45:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:45:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:46:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:46:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:47:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:47:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:47:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:47:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:47:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:47:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:47:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:47:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:47:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:48:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:48:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:48:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:50:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:50:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:50:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:50:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:52:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:52:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:52:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:52:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:52:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:55:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:55:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:55:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:55:34 --> 404 Page Not Found: User/logoutactionsubmit
ERROR - 2020-10-12 14:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:56:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:56:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 14:56:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 14:56:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:02:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 15:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:03:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:03:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:03:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 15:03:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:03:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:16:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-12 15:16:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:16:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:16:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-12 15:16:27 --> 404 Page Not Found: Assets/js

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-02 00:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-02 02:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-02 06:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-02 06:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-02 19:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-02 20:06:20 --> 404 Page Not Found: Robotstxt/index

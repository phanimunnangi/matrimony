<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-21 08:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-21 10:22:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-11-21 16:14:05 --> 404 Page Not Found: Robotstxt/index

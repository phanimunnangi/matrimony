<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-23 04:45:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 04:45:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 04:45:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 05:01:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 05:01:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 05:01:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:42:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 06:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:52:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:52:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:52:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 06:52:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:52:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:53:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 06:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:54:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:54:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:54:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 06:54:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:54:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:55:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 06:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:55:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 06:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 06:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:04:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:04:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:04:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:04:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:04:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:05:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:05:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:05:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:05:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:05:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:07:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:14:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:14:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:14:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:14:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:14:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:15:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:15:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:15:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:15:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:15:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:16:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:16:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:16:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:16:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:16:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:17:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:17:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:17:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:17:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:17:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:19:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:20:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:20:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:20:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:20:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:20:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:20:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:21:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:21:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:21:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:21:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:21:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:21:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:21:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:21:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 07:21:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 07:21:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:06:26 --> Severity: error --> Exception: syntax error, unexpected '.' D:\xampp\htdocs\matrimonywebportal\application\controllers\User.php 61
ERROR - 2020-12-23 08:06:30 --> Severity: error --> Exception: syntax error, unexpected '.' D:\xampp\htdocs\matrimonywebportal\application\controllers\User.php 61
ERROR - 2020-12-23 08:23:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:23:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:23:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 08:23:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:23:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:23:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 08:23:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:23:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:23:30 --> Severity: error --> Exception: syntax error, unexpected '.' D:\xampp\htdocs\matrimonywebportal\application\controllers\User.php 61
ERROR - 2020-12-23 08:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:26:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 08:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 08:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:09:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:09:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:09:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:10:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:10:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:10:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:11:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:11:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:11:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:11:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:11:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:26:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:31:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:31:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:31:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:31:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:31:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:32:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:32:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:32:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:32:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:32:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:32:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:44:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 10:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 10:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:03:41 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' D:\xampp\htdocs\matrimonywebportal\application\controllers\User.php 1502
ERROR - 2020-12-23 13:03:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:03:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:03:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:03:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:03:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:04:10 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' D:\xampp\htdocs\matrimonywebportal\application\controllers\User.php 1502
ERROR - 2020-12-23 13:04:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:04:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:04:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:04:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:04:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:04:50 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' D:\xampp\htdocs\matrimonywebportal\application\controllers\User.php 1502
ERROR - 2020-12-23 13:05:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:05:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:05:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:05:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:05:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:05:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:02 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' D:\xampp\htdocs\matrimonywebportal\application\controllers\User.php 1502
ERROR - 2020-12-23 13:06:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:06:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:06:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:06:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:06:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:21:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:21:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:21:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:21:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:21:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:21:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:52:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:52:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:52:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:52:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:52:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:53:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:53:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:53:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:54:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 13:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 13:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 14:30:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 14:30:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 14:30:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 14:30:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 14:30:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 15:00:17 --> Query error: Unknown column 'ma_users.user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_family_members`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `fmid` = '1'
AND `profile_status` = 1
ERROR - 2020-12-23 15:00:17 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 309
ERROR - 2020-12-23 15:02:23 --> Query error: Unknown column 'ma_users.user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_family_members`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `fmid` = '1'
AND `profile_status` = 1
ERROR - 2020-12-23 15:02:23 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 309
ERROR - 2020-12-23 15:06:05 --> Query error: Unknown column 'ma_users.user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_family_members`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `fmid` = '1'
AND `profile_status` = 1
ERROR - 2020-12-23 15:06:05 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 309
ERROR - 2020-12-23 17:17:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 17:17:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 17:17:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 17:37:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 17:37:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 17:37:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-12-23 17:37:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-23 17:37:08 --> 404 Page Not Found: Assets/js

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-16 18:51:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-16 18:55:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-16 18:58:15 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ')' C:\xampp\htdocs\matrimonywebportal\application\models\admin\Login_model.php 20
ERROR - 2021-10-16 18:58:24 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ')' C:\xampp\htdocs\matrimonywebportal\application\models\admin\Login_model.php 20
ERROR - 2021-10-16 18:58:46 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ')' C:\xampp\htdocs\matrimonywebportal\application\models\admin\Login_model.php 20
ERROR - 2021-10-16 18:59:01 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ')' C:\xampp\htdocs\matrimonywebportal\application\models\admin\Login_model.php 20
ERROR - 2021-10-16 19:00:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-16 19:00:40 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2021-10-16 19:00:40 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Trying to get property 'profile_surname' of non-object C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Trying to get property 'profile_surname' of non-object C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Trying to get property 'profile_surname' of non-object C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Trying to get property 'profile_surname' of non-object C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Trying to get property 'profile_surname' of non-object C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:49 --> Severity: Notice --> Trying to get property 'profile_surname' of non-object C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Trying to get property 'profile_surname' of non-object C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Trying to get property 'profile_surname' of non-object C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Trying to get property 'profile_surname' of non-object C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 100
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_qualification_profession_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 150
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_profession_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 151
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_location C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 152
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_mobile C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 153
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_parnter_blood_group_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 154
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_qualification_profession_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 150
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_profession_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 151
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_location C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 152
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_mobile C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 153
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_parnter_blood_group_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 154
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_qualification_profession_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 150
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_profession_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 151
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_location C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 152
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_mobile C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 153
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_parnter_blood_group_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 154
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_qualification_profession_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 150
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_profession_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 151
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_location C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 152
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_partner_mobile C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 153
ERROR - 2021-10-16 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$profile_parnter_blood_group_name C:\xampp\htdocs\matrimonywebportal\application\views\admin\familymembers.php 154
ERROR - 2021-10-16 19:02:48 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\matrimonywebportal\system\libraries\Session\drivers\Session_files_driver.php 212
ERROR - 2021-10-16 19:02:48 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-10-16 19:02:48 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-10-16 19:05:35 --> Severity: Warning --> mkdir(): Invalid path C:\xampp\htdocs\matrimonywebportal\system\libraries\Session\drivers\Session_files_driver.php 136
ERROR - 2021-10-16 19:05:35 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. C:\xampp\htdocs\matrimonywebportal\system\libraries\Session\drivers\Session_files_driver.php 138
ERROR - 2021-10-16 20:09:16 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-16 20:09:19 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2021-10-16 20:09:19 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2021-10-16 20:09:27 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2021-10-16 20:09:27 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-16 20:10:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-16 20:10:33 --> Severity: Notice --> Undefined variable: femaleselected C:\xampp\htdocs\matrimonywebportal\application\views\admin\waitingprofiles.php 40
ERROR - 2021-10-16 20:10:33 --> Severity: Notice --> Undefined variable: maleselected C:\xampp\htdocs\matrimonywebportal\application\views\admin\waitingprofiles.php 41
ERROR - 2021-10-16 20:10:33 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2021-10-16 20:10:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-16 20:10:57 --> Query error: Unknown column 'us_subscription_days' in 'field list' - Invalid query: INSERT INTO `ma_user_subscriptions` (`us_fromdate`, `us_todate`, `us_paymentamount`, `us_paymentoption`, `us_user_id`, `us_createdat`, `us_subscription_days`) VALUES ('2021-10-17', '2021-11-30', '555', 1, '132', '2021-10-16 20:10:57', '44')
ERROR - 2021-10-16 20:11:10 --> Severity: Notice --> Undefined variable: femaleselected C:\xampp\htdocs\matrimonywebportal\application\views\admin\waitingprofiles.php 40
ERROR - 2021-10-16 20:11:10 --> Severity: Notice --> Undefined variable: maleselected C:\xampp\htdocs\matrimonywebportal\application\views\admin\waitingprofiles.php 41
ERROR - 2021-10-16 20:11:10 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2021-10-16 20:11:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-16 20:11:30 --> Query error: Unknown column 'us_subscription_days' in 'field list' - Invalid query: INSERT INTO `ma_user_subscriptions` (`us_fromdate`, `us_todate`, `us_paymentamount`, `us_paymentoption`, `us_user_id`, `us_createdat`, `us_subscription_days`) VALUES ('2021-10-17', '2021-11-22', '88888', 1, '132', '2021-10-16 20:11:30', '36')
ERROR - 2021-10-16 20:11:39 --> Severity: Notice --> Undefined variable: page_title C:\xampp\htdocs\matrimonywebportal\application\views\includes\header.php 42

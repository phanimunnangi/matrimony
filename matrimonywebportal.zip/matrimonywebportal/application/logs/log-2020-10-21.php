<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-21 01:18:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:18:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:18:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:33:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:33:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:33:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:33:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:33:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:34:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:34:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:34:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:34:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:34:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:35:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:35:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:37:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:37:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:37:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:37:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:37:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:37:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:56:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:56:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:56:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:56:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:57:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:57:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:57:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 01:57:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 01:57:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:06:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:06:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:06:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:06:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:06:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:34:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:34:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:34:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:34:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:34:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:46:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:46:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:46:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:46:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:46:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:47:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:47:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:47:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:47:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:47:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:48:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:48:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:48:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:48:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:48:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:49:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:49:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:49:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:49:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:49:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:51:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:51:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:51:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:51:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:51:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:55:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:55:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:55:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:55:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:55:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:56:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:56:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:56:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:56:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:56:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:56:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:56:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:56:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:57:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:59:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:59:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:59:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 02:59:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 02:59:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:01:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:01:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:01:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:02:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:02:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:02:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:02:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:02:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:03:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:04:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:04:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:04:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:04:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:06:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:06:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:06:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:06:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:06:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:06:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:06:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:06:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:06:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:06:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:07:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:07:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:07:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:25:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:25:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:25:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:26:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 03:26:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:26:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 03:56:40 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:57:11 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:57:46 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:58:25 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:58:56 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:37 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:38 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:38 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:38 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:38 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:38 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:39 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:39 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:39 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:39 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:39 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:40 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 03:59:40 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 04:00:20 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 04:00:47 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 04:01:41 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 04:02:01 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 04:03:10 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 04:04:44 --> Severity: Notice --> Undefined property: User::$pagination D:\xampp\htdocs\matrimonyapp\application\controllers\User.php 70
ERROR - 2020-10-21 04:04:44 --> Severity: error --> Exception: Call to a member function initialize() on null D:\xampp\htdocs\matrimonyapp\application\controllers\User.php 70
ERROR - 2020-10-21 04:06:08 --> Severity: error --> Exception: syntax error, unexpected '$limit' (T_VARIABLE), expecting ')' D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 286
ERROR - 2020-10-21 04:06:24 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 311
ERROR - 2020-10-21 04:06:26 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 311
ERROR - 2020-10-21 04:06:43 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 311
ERROR - 2020-10-21 04:06:45 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 311
ERROR - 2020-10-21 04:13:34 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:14:49 --> 404 Page Not Found: Searchprofiles/2
ERROR - 2020-10-21 04:17:44 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:29:35 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:30:21 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:30:21 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:30:21 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:21 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:21 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:30:21 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:30:21 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:30:21 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:30:22 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:26 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:27 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:27 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:27 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:27 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:27 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:27 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:29 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:31:30 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 168
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:32:42 --> Severity: Notice --> Undefined index: userGender D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 163
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_education_qualifications D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 158
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_profession_name D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:33:05 --> Severity: Notice --> Undefined property: stdClass::$ued_place_work D:\xampp\htdocs\matrimonyapp\application\views\searchprofiles.php 159
ERROR - 2020-10-21 04:34:12 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:34:34 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:35:42 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:35:44 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:35:47 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:35:55 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:36:27 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:36:32 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:38:17 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:38:19 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:38:34 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:38:43 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:38:50 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:39:32 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:40:34 --> Severity: Notice --> Undefined index: page D:\xampp\htdocs\matrimonyapp\application\controllers\User.php 70
ERROR - 2020-10-21 04:43:05 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:43:18 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:44:25 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:44:30 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:44:34 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:44:40 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:44:45 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:45:00 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:45:49 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:50:33 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:50:39 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:50:46 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:50:52 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:50:55 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:50:58 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:51:01 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:51:05 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:51:13 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:57:43 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:57:47 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 04:58:15 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\matrimonyapp\system\libraries\Pagination.php 504
ERROR - 2020-10-21 04:58:22 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\matrimonyapp\system\libraries\Pagination.php 504
ERROR - 2020-10-21 04:58:52 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 05:05:48 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 05:07:58 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 05:08:03 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 05:08:54 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 05:14:04 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 05:14:09 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 05:14:13 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 05:14:18 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 05:15:21 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 42
ERROR - 2020-10-21 08:45:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 08:45:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 08:45:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 08:45:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM ma_users u LEFT JOIN ma_user_restricted_details urd ON urd.urd_user_id = u.user_id LEFT JOIN ma_user_personal_info upi ON upi.upi_user_id = u.user_id LEFT JOIN ma_user_partner_prefered_details uppd ON uppd.uppd_user_id = u.user_id LEFT JOIN ma_user_educational_details ued ON ued.ued_user_id = u.user_id WHERE user_registeredid = 'B201033' AND user_status=1 AND user_payment_status=1 AND user_settleted_status=0 ORDER BY user_id DESC LIMIT ,
ERROR - 2020-10-21 08:45:59 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 301
ERROR - 2020-10-21 08:47:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM ma_users u LEFT JOIN ma_user_restricted_details urd ON urd.urd_user_id = u.user_id LEFT JOIN ma_user_personal_info upi ON upi.upi_user_id = u.user_id LEFT JOIN ma_user_partner_prefered_details uppd ON uppd.uppd_user_id = u.user_id LEFT JOIN ma_user_educational_details ued ON ued.ued_user_id = u.user_id WHERE user_registeredid = 'B201033' AND user_status=1 AND user_payment_status=1 AND user_settleted_status=0 ORDER BY user_id DESC LIMIT ,
ERROR - 2020-10-21 08:47:03 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 301
ERROR - 2020-10-21 08:47:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM ma_users u LEFT JOIN ma_user_restricted_details urd ON urd.urd_user_id = u.user_id LEFT JOIN ma_user_personal_info upi ON upi.upi_user_id = u.user_id LEFT JOIN ma_user_partner_prefered_details uppd ON uppd.uppd_user_id = u.user_id LEFT JOIN ma_user_educational_details ued ON ued.ued_user_id = u.user_id WHERE user_registeredid = 'B201033' AND user_status=1 AND user_payment_status=1 AND user_settleted_status=0 ORDER BY user_id DESC LIMIT ,
ERROR - 2020-10-21 08:47:17 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 301
ERROR - 2020-10-21 08:49:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 08:49:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 08:49:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 08:49:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 08:49:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:12:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:12:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:12:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:12:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:12:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:12:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:13:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:13:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:13:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:13:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:13:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:13:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:13:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:13:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:13:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:13:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:15:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:15:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:15:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:15:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:15:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:17:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:17:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:17:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:17:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:17:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:18:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:18:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:18:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:18:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:28:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:28:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:28:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 09:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 09:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 10:17:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 10:17:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 10:17:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 10:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 10:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 10:18:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 10:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 10:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:02:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:02:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:02:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 14:02:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:02:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 14:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 14:03:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 14:03:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:03:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:04:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 14:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:47:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:47:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:47:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 14:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:56:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 14:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 14:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:14:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:14:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:14:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 15:49:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:49:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:49:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 15:49:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:49:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:49:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:49:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:49:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 15:49:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 15:49:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:01:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:01:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:01:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:02:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:02:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:02:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:02:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:02:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:03:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:03:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:03:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:03:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:04:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:04:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:04:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:04:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:04:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:04:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:04:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:04:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:04:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:04:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:06:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:06:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:06:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:06:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:06:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:06:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:07:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:07:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:07:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:08:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:08:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:08:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:08:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:08:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:08:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:08:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:08:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-21 16:08:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-21 16:08:12 --> 404 Page Not Found: Assets/js

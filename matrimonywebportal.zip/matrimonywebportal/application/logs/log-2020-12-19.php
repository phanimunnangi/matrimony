<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-19 06:01:10 --> Severity: Notice --> Undefined variable: refferal_userid D:\xampp\htdocs\matrimonywebportal\application\controllers\User.php 1475
ERROR - 2020-12-19 06:01:13 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 06:11:15 --> Query error: Unknown column 'NAYEEBRAHMIN01' in 'where clause' - Invalid query: SELECT *
FROM `ma_referal_codes`
WHERE `NAYEEBRAHMIN01` = 'rfname'
ERROR - 2020-12-19 06:11:15 --> Severity: error --> Exception: Call to a member function result() on boolean D:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 28
ERROR - 2020-12-19 06:15:29 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 06:16:33 --> Query error: Unknown column 'rfusedcount' in 'field list' - Invalid query: INSERT INTO `ma_referal_used_users` (`rfusedcount`) VALUES (1)
ERROR - 2020-12-19 06:16:35 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 06:18:29 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 06:22:23 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 06:41:36 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 07:05:07 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 07:06:00 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 07:08:35 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 13:05:16 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 13:18:39 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49
ERROR - 2020-12-19 13:29:07 --> 404 Page Not Found: Assets/css

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-23 05:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-23 18:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-23 19:12:37 --> 404 Page Not Found: Robotstxt/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-23 05:08:11 --> 404 Page Not Found: Assets/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-23 05:08:11 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-23 05:08:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-23 05:12:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-23 05:12:34 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-23 05:12:34 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-23 05:25:42 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-23 05:25:42 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-23 05:25:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-23 05:26:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-23 05:26:03 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-23 05:26:03 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-23 05:26:03 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-23 05:26:03 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-23 07:21:29 --> Severity: Notice --> Undefined variable: reported D:\xampp\htdocs\matrimonywebportal\application\helpers\common_helper.php 49

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-27 01:40:33 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2021-10-27 01:40:38 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-27 01:40:43 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-27 01:40:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-27 01:41:03 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-27 01:41:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-27 01:42:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-27 01:46:33 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-27 01:48:54 --> 404 Page Not Found: admin/Common/skin-config.html

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-31 18:22:20 --> 404 Page Not Found: Robotstxt/index

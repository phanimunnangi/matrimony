<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-06 05:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-06 14:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-06 19:51:03 --> 404 Page Not Found: Blog/index

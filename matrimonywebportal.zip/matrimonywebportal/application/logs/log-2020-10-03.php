<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-03 05:54:28 --> Severity: Notice --> Undefined property: LoaddingPage::$data D:\xampp\htdocs\matrimonyapp\application\core\MY_Controller.php 67
ERROR - 2020-10-03 05:54:28 --> Severity: Notice --> Undefined index: PATH_INFO D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 2
ERROR - 2020-10-03 05:54:28 --> Severity: Notice --> Undefined variable: page_title D:\xampp\htdocs\matrimonyapp\application\views\includes\header.php 38
ERROR - 2020-10-03 05:54:28 --> Severity: Notice --> Undefined property: LoaddingPage::$data D:\xampp\htdocs\matrimonyapp\application\core\MY_Controller.php 68
ERROR - 2020-10-03 05:56:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-03 05:56:55 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-03 05:56:55 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-03 05:57:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-03 05:57:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-03 05:57:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-03 05:57:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-03 05:57:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-03 05:57:24 --> 404 Page Not Found: admin/Common/skin-config.html

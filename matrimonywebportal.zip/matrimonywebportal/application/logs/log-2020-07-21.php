<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-21 11:53:58 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 11:54:02 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 11:54:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-07-21 12:02:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-07-21 12:04:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-07-21 12:04:35 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-07-21 12:05:31 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-07-21 12:06:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-07-21 12:06:33 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:06:39 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:06:46 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:08:05 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:12:01 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:13:23 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:13:26 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:13:29 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:13:32 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 16:43:54 --> Severity: Warning --> move_uploaded_file(../product_images/21072020164354gmail.JPG): failed to open stream: No such file or directory D:\xampp\htdocs\admin-dashboard\application\controllers\admin\Settings.php 148
ERROR - 2020-07-21 16:43:54 --> Severity: Warning --> move_uploaded_file(): Unable to move 'D:\xampp\tmp\php3A5E.tmp' to '../product_images/21072020164354gmail.JPG' D:\xampp\htdocs\admin-dashboard\application\controllers\admin\Settings.php 148
ERROR - 2020-07-21 16:43:54 --> Severity: Warning --> move_uploaded_file(../product_images/21072020164354gmail.JPG): failed to open stream: No such file or directory D:\xampp\htdocs\admin-dashboard\application\controllers\admin\Settings.php 158
ERROR - 2020-07-21 16:43:54 --> Severity: Warning --> move_uploaded_file(): Unable to move 'D:\xampp\tmp\php3A5F.tmp' to '../product_images/21072020164354gmail.JPG' D:\xampp\htdocs\admin-dashboard\application\controllers\admin\Settings.php 158
ERROR - 2020-07-21 12:13:55 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:14:08 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:14:14 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:14:40 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 12:14:49 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:05:27 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-07-21 18:05:27 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-07-21 18:05:27 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-07-21 18:05:33 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-07-21 18:05:34 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-07-21 18:06:49 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-07-21 18:06:53 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:06:57 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:10:57 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:10:59 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:21:13 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:21:22 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-07-21 18:21:27 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:21:30 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:22:07 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:22:11 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:22:43 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:23:02 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-07-21 18:23:02 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-07-21 18:23:31 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-07-21 18:23:32 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-07-21 18:23:32 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-07-21 18:23:38 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-07-21 18:23:40 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:23:44 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 22:54:08 --> Severity: Warning --> move_uploaded_file(../product_images/21072020225408logo.png): failed to open stream: No such file or directory D:\xampp\htdocs\admin-dashboard\application\controllers\admin\Settings.php 148
ERROR - 2020-07-21 22:54:08 --> Severity: Warning --> move_uploaded_file(): Unable to move 'D:\xampp\tmp\php2CD2.tmp' to '../product_images/21072020225408logo.png' D:\xampp\htdocs\admin-dashboard\application\controllers\admin\Settings.php 148
ERROR - 2020-07-21 22:54:08 --> Severity: Warning --> move_uploaded_file(../product_images/21072020225408logo.png): failed to open stream: No such file or directory D:\xampp\htdocs\admin-dashboard\application\controllers\admin\Settings.php 158
ERROR - 2020-07-21 22:54:08 --> Severity: Warning --> move_uploaded_file(): Unable to move 'D:\xampp\tmp\php2CD3.tmp' to '../product_images/21072020225408logo.png' D:\xampp\htdocs\admin-dashboard\application\controllers\admin\Settings.php 158
ERROR - 2020-07-21 18:24:09 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:24:16 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-07-21 18:24:25 --> 404 Page Not Found: admin/Settings/skin-config.html

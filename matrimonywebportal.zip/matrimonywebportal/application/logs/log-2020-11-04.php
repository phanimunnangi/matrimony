<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-04 05:16:03 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-04 05:16:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-04 08:07:14 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-04 08:07:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-04 10:07:02 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-04 10:07:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-04 10:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-04 12:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-04 13:53:56 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-04 13:53:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-04 17:50:13 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-04 17:50:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-04 20:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-04 22:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-04 23:09:47 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-04 23:09:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564

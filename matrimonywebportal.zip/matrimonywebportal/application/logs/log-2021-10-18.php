<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-18 04:11:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'u942381587_matrimony'@'localhost' (using password: YES) /home/u942381587/domains/siripromoters.com/public_html/matrimonywebportal/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-10-18 04:11:26 --> Unable to connect to the database
ERROR - 2021-10-18 04:11:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'u942381587_matrimony'@'localhost' (using password: YES) /home/u942381587/domains/siripromoters.com/public_html/matrimonywebportal/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-10-18 04:11:52 --> Unable to connect to the database
ERROR - 2021-10-18 04:12:43 --> Severity: Notice --> Undefined variable: page_title /home/u942381587/domains/siripromoters.com/public_html/matrimonywebportal/application/views/includes/header.php 42
ERROR - 2021-10-18 04:13:23 --> Severity: Notice --> Undefined variable: page_title /home/u942381587/domains/siripromoters.com/public_html/matrimonywebportal/application/views/includes/header.php 42
ERROR - 2021-10-18 04:13:27 --> 404 Page Not Found: admin//index
ERROR - 2021-10-18 04:15:57 --> 404 Page Not Found: admin//index
ERROR - 2021-10-18 04:16:02 --> 404 Page Not Found: admin/Admin/index
ERROR - 2021-10-18 04:17:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-18 04:17:43 --> 404 Page Not Found: Admindashboard/index
ERROR - 2021-10-18 04:23:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-18 04:41:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-18 04:44:34 --> 404 Page Not Found: Assets/images

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-12 02:24:38 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-12 02:24:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-12 02:36:55 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-12 02:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-12 03:53:33 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-12 04:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-12 04:39:24 --> 404 Page Not Found: Uploads/members
ERROR - 2020-11-12 04:52:32 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-12 04:52:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-12 05:20:07 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2020-11-12 11:01:28 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-12 11:01:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-12 15:14:01 --> 404 Page Not Found: Images/slider
ERROR - 2020-11-12 17:30:07 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-11-12 17:30:11 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-11-12 17:30:11 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-11-12 17:30:11 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-11-12 17:30:12 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-11-12 17:30:12 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-11-12 17:30:13 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-11-12 17:30:13 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-11-12 17:30:13 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-11-12 17:30:14 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-11-12 17:30:14 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2020-11-12 17:30:14 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-11-12 17:30:15 --> 404 Page Not Found: Media/wp-includes
ERROR - 2020-11-12 17:30:15 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-11-12 17:30:16 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-11-12 17:30:16 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-11-12 17:30:17 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2020-11-12 18:46:10 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-12 18:46:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-12 19:08:56 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-12 19:08:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-12 21:36:57 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-12 21:36:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-12 23:29:38 --> 404 Page Not Found: Member/details
ERROR - 2020-11-12 23:41:09 --> 404 Page Not Found: Robotstxt/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-20 08:01:58 --> 404 Page Not Found: Viewprofile/G201001
ERROR - 2020-10-20 08:08:17 --> 404 Page Not Found: Viewprofile/G201001
ERROR - 2020-10-20 08:08:20 --> 404 Page Not Found: Viewprofile/G201001
ERROR - 2020-10-20 08:33:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 08:33:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 08:33:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 08:46:21 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\matrimonyapp\application\views\viewprofile.php 156
ERROR - 2020-10-20 08:46:23 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\matrimonyapp\application\views\viewprofile.php 156
ERROR - 2020-10-20 12:36:04 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:36:04 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:36:42 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:36:43 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:37:32 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:37:32 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:37:33 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:37:33 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:37:49 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:37:49 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:37:49 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:37:50 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:37:50 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:37:50 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:37:50 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:37:50 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:37:50 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:37:50 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:40:03 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:40:04 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:40:04 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:40:04 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:40:25 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:40:25 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:41:04 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:41:04 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:41:34 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:41:34 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:43:41 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:43:41 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 12:43:42 --> Query error: Not unique table/alias: 'ma_user_family_details' - Invalid query: SELECT *
FROM `ma_users`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
WHERE `user_registeredid` = 'G201001'
AND `user_status` = 1
ERROR - 2020-10-20 12:43:42 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 285
ERROR - 2020-10-20 13:23:36 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given D:\xampp\htdocs\matrimonyapp\application\controllers\User.php 15
ERROR - 2020-10-20 16:41:37 --> 404 Page Not Found: Editprofile/index
ERROR - 2020-10-20 16:53:38 --> 404 Page Not Found: Images/banners
ERROR - 2020-10-20 17:02:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 17:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:03:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 17:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 17:03:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:03:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:05:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 17:06:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 17:06:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 17:06:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 17:06:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 17:06:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:06:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:07:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 17:07:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:07:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:07:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 17:09:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 17:09:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:09:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:09:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-20 17:09:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:09:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-20 17:40:42 --> 404 Page Not Found: Images/banners
ERROR - 2020-10-20 17:40:42 --> 404 Page Not Found: Images/banners
ERROR - 2020-10-20 17:40:42 --> 404 Page Not Found: Images/bride
ERROR - 2020-10-20 17:41:36 --> 404 Page Not Found: Images/bride
ERROR - 2020-10-20 17:42:00 --> 404 Page Not Found: Images/bride
ERROR - 2020-10-20 18:02:34 --> 404 Page Not Found: Images/banners

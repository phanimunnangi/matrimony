<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-28 00:09:05 --> 404 Page Not Found: admin//index
ERROR - 2020-11-28 02:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-28 02:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-28 11:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-28 12:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-28 21:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-28 21:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-28 23:18:41 --> 404 Page Not Found: Robotstxt/index

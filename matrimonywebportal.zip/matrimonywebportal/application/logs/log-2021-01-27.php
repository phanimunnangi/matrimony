<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-27 10:14:01 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-27 10:14:01 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-27 10:14:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-27 10:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-27 10:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-27 10:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-27 10:15:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-01-27 10:15:52 --> 404 Page Not Found: Assets/js
ERROR - 2021-01-27 10:15:52 --> 404 Page Not Found: Assets/js

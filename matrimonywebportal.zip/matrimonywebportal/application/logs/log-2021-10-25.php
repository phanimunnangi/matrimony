<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-25 15:17:00 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2021-10-25 15:17:00 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2021-10-25 15:17:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2021-10-25 15:17:07 --> 404 Page Not Found: admin/Common/skin-config.html

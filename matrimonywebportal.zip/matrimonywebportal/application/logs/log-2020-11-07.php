<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-07 01:02:25 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-07 01:02:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-07 02:25:13 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-07 02:25:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-07 02:41:08 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-11-07 03:54:05 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-07 03:54:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-07 11:24:37 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-07 11:24:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-07 16:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-07 21:45:41 --> 404 Page Not Found: Robotstxt/index

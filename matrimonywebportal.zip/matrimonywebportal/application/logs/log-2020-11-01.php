<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-01 00:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-01 00:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-01 04:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-01 10:58:05 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-11-01 10:58:07 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-11-01 10:58:07 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-11-01 10:58:07 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-11-01 10:58:08 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-11-01 10:58:08 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-11-01 10:58:08 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-11-01 10:58:09 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-11-01 10:58:09 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-11-01 10:58:09 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-11-01 10:58:09 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2020-11-01 10:58:10 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-11-01 10:58:10 --> 404 Page Not Found: Media/wp-includes
ERROR - 2020-11-01 10:58:10 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-11-01 10:58:10 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-11-01 10:58:11 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-11-01 10:58:11 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2020-11-01 12:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-01 15:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-01 18:16:09 --> 404 Page Not Found: Robotstxt/index

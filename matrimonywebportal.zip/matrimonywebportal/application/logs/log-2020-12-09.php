<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-09 09:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-09 16:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-09 17:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-09 17:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-09 21:13:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-09 21:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-09 21:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-09 21:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-09 22:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-09 22:59:44 --> 404 Page Not Found: Robotstxt/index

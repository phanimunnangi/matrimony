<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-06 05:49:03 --> 404 Page Not Found: admin//index
ERROR - 2020-10-06 05:51:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-06 05:51:27 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-06 05:51:27 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-06 05:51:30 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:35 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:38 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:47 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:56 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:51:58 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:52:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:52:03 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:52:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 05:52:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:17:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:17:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:17:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:17:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:17:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:27 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:35 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:36 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:36 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:36 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:37 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:37 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:37 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:18:38 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:18:38 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:19:23 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:19:24 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:19:24 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-06 06:19:24 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:19:24 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 06:19:24 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-06 06:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 68
ERROR - 2020-10-06 06:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 176
ERROR - 2020-10-06 06:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 06:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 214
ERROR - 2020-10-06 06:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 336
ERROR - 2020-10-06 06:22:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:42:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 98
ERROR - 2020-10-06 06:42:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 206
ERROR - 2020-10-06 06:42:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 219
ERROR - 2020-10-06 06:42:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 244
ERROR - 2020-10-06 06:42:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 366
ERROR - 2020-10-06 06:42:28 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 84
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 205
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 230
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 352
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 962
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 1070
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 1083
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 1108
ERROR - 2020-10-06 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 1230
ERROR - 2020-10-06 06:43:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 84
ERROR - 2020-10-06 06:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 06:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 205
ERROR - 2020-10-06 06:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 230
ERROR - 2020-10-06 06:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 352
ERROR - 2020-10-06 06:44:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 84
ERROR - 2020-10-06 06:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 06:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 205
ERROR - 2020-10-06 06:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 230
ERROR - 2020-10-06 06:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 352
ERROR - 2020-10-06 06:44:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 84
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 205
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 230
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 352
ERROR - 2020-10-06 06:44:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 84
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 205
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 230
ERROR - 2020-10-06 06:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 352
ERROR - 2020-10-06 06:44:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:27 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:54:43 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 06:55:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 06:55:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 06:55:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 06:55:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 06:55:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 06:55:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 14:34:18 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-06 14:34:26 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-06 14:34:30 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-06 14:34:30 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 14:35:06 --> 404 Page Not Found: admin/Common/add-profile
ERROR - 2020-10-06 14:35:14 --> 404 Page Not Found: admin/Common/add-profile
ERROR - 2020-10-06 14:56:22 --> 404 Page Not Found: admin/Common/add-profile
ERROR - 2020-10-06 16:24:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 16:24:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 16:24:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 16:24:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 16:24:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 16:24:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:24:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-06 16:24:12 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-06 16:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 16:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 16:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 16:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 16:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 16:24:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 80
ERROR - 2020-10-06 16:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 16:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 201
ERROR - 2020-10-06 16:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 226
ERROR - 2020-10-06 16:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 348
ERROR - 2020-10-06 16:32:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 151
ERROR - 2020-10-06 16:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 164
ERROR - 2020-10-06 16:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 16:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 311
ERROR - 2020-10-06 16:46:38 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:47:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 151
ERROR - 2020-10-06 16:47:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 164
ERROR - 2020-10-06 16:47:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 16:47:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 311
ERROR - 2020-10-06 16:47:38 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 151
ERROR - 2020-10-06 16:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 164
ERROR - 2020-10-06 16:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 16:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 311
ERROR - 2020-10-06 16:48:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 151
ERROR - 2020-10-06 16:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 164
ERROR - 2020-10-06 16:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 189
ERROR - 2020-10-06 16:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 311
ERROR - 2020-10-06 16:48:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:48:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 154
ERROR - 2020-10-06 16:48:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 167
ERROR - 2020-10-06 16:48:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 16:48:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 314
ERROR - 2020-10-06 16:48:31 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:48:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 154
ERROR - 2020-10-06 16:48:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 167
ERROR - 2020-10-06 16:48:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 16:48:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 314
ERROR - 2020-10-06 16:48:47 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:49:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 154
ERROR - 2020-10-06 16:49:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 167
ERROR - 2020-10-06 16:49:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 16:49:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 314
ERROR - 2020-10-06 16:49:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 154
ERROR - 2020-10-06 16:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 167
ERROR - 2020-10-06 16:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 16:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 314
ERROR - 2020-10-06 16:50:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:50:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 154
ERROR - 2020-10-06 16:50:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 167
ERROR - 2020-10-06 16:50:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 16:50:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 314
ERROR - 2020-10-06 16:50:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 154
ERROR - 2020-10-06 16:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 167
ERROR - 2020-10-06 16:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 192
ERROR - 2020-10-06 16:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 314
ERROR - 2020-10-06 16:50:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 157
ERROR - 2020-10-06 16:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 170
ERROR - 2020-10-06 16:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 195
ERROR - 2020-10-06 16:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 317
ERROR - 2020-10-06 16:51:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:52:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 157
ERROR - 2020-10-06 16:52:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 170
ERROR - 2020-10-06 16:52:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 195
ERROR - 2020-10-06 16:52:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 317
ERROR - 2020-10-06 16:52:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:53:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 157
ERROR - 2020-10-06 16:53:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 170
ERROR - 2020-10-06 16:53:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 195
ERROR - 2020-10-06 16:53:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 317
ERROR - 2020-10-06 16:53:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 157
ERROR - 2020-10-06 16:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 170
ERROR - 2020-10-06 16:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 195
ERROR - 2020-10-06 16:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 317
ERROR - 2020-10-06 16:54:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 160
ERROR - 2020-10-06 16:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 173
ERROR - 2020-10-06 16:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 198
ERROR - 2020-10-06 16:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 320
ERROR - 2020-10-06 16:54:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 160
ERROR - 2020-10-06 16:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 173
ERROR - 2020-10-06 16:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 198
ERROR - 2020-10-06 16:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 320
ERROR - 2020-10-06 16:55:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:56:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 161
ERROR - 2020-10-06 16:56:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 174
ERROR - 2020-10-06 16:56:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 199
ERROR - 2020-10-06 16:56:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 321
ERROR - 2020-10-06 16:56:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:56:17 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-06 16:56:17 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 16:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 161
ERROR - 2020-10-06 16:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 174
ERROR - 2020-10-06 16:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 199
ERROR - 2020-10-06 16:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 321
ERROR - 2020-10-06 16:56:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:56:44 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 16:56:44 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-06 16:56:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 161
ERROR - 2020-10-06 16:56:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 174
ERROR - 2020-10-06 16:56:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 199
ERROR - 2020-10-06 16:56:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 321
ERROR - 2020-10-06 16:56:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:56:46 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 16:56:46 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-06 16:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 164
ERROR - 2020-10-06 16:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 177
ERROR - 2020-10-06 16:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 202
ERROR - 2020-10-06 16:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 324
ERROR - 2020-10-06 16:58:36 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 16:58:36 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:58:37 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-06 16:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 164
ERROR - 2020-10-06 16:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 177
ERROR - 2020-10-06 16:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 202
ERROR - 2020-10-06 16:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 324
ERROR - 2020-10-06 16:58:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 16:58:41 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 16:58:42 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-06 17:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 162
ERROR - 2020-10-06 17:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 175
ERROR - 2020-10-06 17:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 200
ERROR - 2020-10-06 17:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 322
ERROR - 2020-10-06 17:01:51 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 17:01:52 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-06 17:01:52 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-06 17:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 175
ERROR - 2020-10-06 17:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 17:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 213
ERROR - 2020-10-06 17:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 335
ERROR - 2020-10-06 17:06:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 17:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 175
ERROR - 2020-10-06 17:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 17:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 213
ERROR - 2020-10-06 17:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 335
ERROR - 2020-10-06 17:06:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 17:06:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 175
ERROR - 2020-10-06 17:06:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 17:06:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 213
ERROR - 2020-10-06 17:06:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 335
ERROR - 2020-10-06 17:06:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 17:06:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 175
ERROR - 2020-10-06 17:06:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 17:06:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 213
ERROR - 2020-10-06 17:06:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 335
ERROR - 2020-10-06 17:06:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 17:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 175
ERROR - 2020-10-06 17:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 17:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 213
ERROR - 2020-10-06 17:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 335
ERROR - 2020-10-06 17:07:03 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 17:07:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 175
ERROR - 2020-10-06 17:07:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 188
ERROR - 2020-10-06 17:07:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 213
ERROR - 2020-10-06 17:07:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 335
ERROR - 2020-10-06 17:07:47 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 17:08:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 272
ERROR - 2020-10-06 17:08:42 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-06 17:09:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\add-profile.php 271
ERROR - 2020-10-06 17:09:12 --> 404 Page Not Found: admin/Common/skin-config.html

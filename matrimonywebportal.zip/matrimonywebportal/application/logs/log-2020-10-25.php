<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-25 05:27:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-25 05:29:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:29:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:29:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 05:32:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 05:32:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:32:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:32:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:32:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:32:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 05:32:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:32:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:32:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:32:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:33:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 05:33:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:33:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:33:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:33:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:33:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 05:33:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:33:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:33:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:33:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:34:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 05:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:41:59 --> 404 Page Not Found: Matrimoanyappadmindashboard/index
ERROR - 2020-10-25 05:42:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-25 05:42:35 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-25 05:42:35 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-25 05:52:29 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 05:52:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 05:55:48 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-25 05:55:53 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 05:56:04 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 05:56:27 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 05:56:34 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 05:57:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:57:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:57:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 05:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:57:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:57:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 05:57:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 05:57:23 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 06:02:53 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 06:03:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:03:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:03:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 06:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:04:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 06:04:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:04:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:04:51 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 06:04:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 06:15:12 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/matrimonyapp/public_html/demo/application/views/index.php 614
ERROR - 2020-10-25 06:15:14 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/matrimonyapp/public_html/demo/application/views/index.php 614
ERROR - 2020-10-25 06:22:43 --> Severity: Parsing Error --> syntax error, unexpected '}' /home2/matrimonyapp/public_html/demo/application/views/profiles.php 201
ERROR - 2020-10-25 06:22:46 --> Severity: Parsing Error --> syntax error, unexpected '}' /home2/matrimonyapp/public_html/demo/application/views/profiles.php 201
ERROR - 2020-10-25 06:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:27:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 06:30:04 --> 404 Page Not Found: Userpics/photonot.jpg
ERROR - 2020-10-25 06:30:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:30:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:30:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 06:30:14 --> 404 Page Not Found: Userpics/photonot.jpg
ERROR - 2020-10-25 06:30:31 --> 404 Page Not Found: Userpics/photonot.jpg
ERROR - 2020-10-25 06:30:34 --> 404 Page Not Found: Userpics/photonot.jpg
ERROR - 2020-10-25 06:30:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 06:30:42 --> 404 Page Not Found: Userpics/photonot.jpg
ERROR - 2020-10-25 06:30:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:30:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:30:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:30:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:30:46 --> 404 Page Not Found: Userpics/photonot.jpg
ERROR - 2020-10-25 06:31:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 06:31:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:31:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:31:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:31:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:41:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:41:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:41:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 06:41:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 06:41:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:41:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:57:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:57:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 06:57:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 07:04:33 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 07:04:44 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 07:09:02 --> 404 Page Not Found: Matrimonydashboard/index
ERROR - 2020-10-25 07:11:00 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-25 07:11:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-25 07:11:58 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-25 07:11:58 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-25 07:12:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:14:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:14:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:15:07 --> 404 Page Not Found: Service-info/index
ERROR - 2020-10-25 07:16:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:16:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:16:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:16:36 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:17:33 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:17:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:18:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:19:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:19:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:19:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 07:19:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:19:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 07:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:19:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:19:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:20:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:20:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:20:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 07:20:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:20:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:20:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:20:30 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:20:39 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:21:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:21:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:21:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:21:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:22:58 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:23:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:23:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 07:23:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 07:23:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 07:23:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 07:23:36 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/matrimonyapp/public_html/demo/application/views/index.php 313
ERROR - 2020-10-25 07:23:39 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/matrimonyapp/public_html/demo/application/views/index.php 453
ERROR - 2020-10-25 07:24:32 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:24:33 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:24:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:25:24 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:25:26 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:25:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:26:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:26:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:26:30 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:27:20 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:28:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:28:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:29:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:29:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:29:38 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:29:39 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:09 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:09 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:30:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:31:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:31:32 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:31:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:32:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:33:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:33:26 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:33:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:34:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:34:35 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:34:56 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:35:31 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:35:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:35:58 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:35:59 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:35:59 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:36:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:36:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:36:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:36:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:36:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:36:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:36:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:36:33 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:36:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:37:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:37:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:38:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:38:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:38:39 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:38:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:46:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:46:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:46:56 --> Severity: Error --> Call to undefined method Common_model::get_user_liked_profiles() /home2/matrimonyapp/public_html/demo/application/controllers/User.php 72
ERROR - 2020-10-25 07:46:59 --> Severity: Error --> Call to undefined method Common_model::get_user_liked_profiles() /home2/matrimonyapp/public_html/demo/application/controllers/User.php 72
ERROR - 2020-10-25 07:52:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:09 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:52:59 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:53:23 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:53:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:54:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:55:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:55:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:55:33 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 07:56:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-25 07:59:21 --> Severity: Parsing Error --> syntax error, unexpected '$table' (T_VARIABLE) /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-25 08:00:18 --> Severity: Parsing Error --> syntax error, unexpected '$table' (T_VARIABLE) /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-25 08:00:23 --> Severity: Parsing Error --> syntax error, unexpected '$table' (T_VARIABLE) /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-25 08:00:25 --> Severity: Parsing Error --> syntax error, unexpected '$table' (T_VARIABLE) /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-25 08:00:26 --> Severity: Parsing Error --> syntax error, unexpected '$table' (T_VARIABLE) /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-25 08:00:27 --> Severity: Parsing Error --> syntax error, unexpected '$table' (T_VARIABLE) /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-25 08:00:35 --> Severity: Parsing Error --> syntax error, unexpected '$table' (T_VARIABLE) /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-25 08:00:49 --> Severity: Parsing Error --> syntax error, unexpected '$table' (T_VARIABLE) /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-25 08:00:57 --> Query error: Unknown column 'ma_users.upi_user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_user_liked_profiles`
LEFT JOIN `ma_users` ON `ma_users`.`upi_user_id` = `ma_user_liked_profiles`.`ulp_user_id_to`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
WHERE `ulp_status` = 1
AND `user_settleted_status` = 0
AND `user_payment_status` = 1
AND `ulp_user_id_from` = '22'
ORDER BY `ulp_user_id_to` DESC
 LIMIT 5
ERROR - 2020-10-25 08:00:57 --> Severity: Error --> Call to a member function result() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 270
ERROR - 2020-10-25 08:01:23 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:01:33 --> Query error: Unknown column 'ma_users.upi_user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_user_liked_profiles`
LEFT JOIN `ma_users` ON `ma_users`.`upi_user_id` = `ma_user_liked_profiles`.`ulp_user_id_to`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
WHERE `ulp_status` = 1
AND `user_settleted_status` = 0
AND `user_payment_status` = 1
AND `ulp_user_id_from` = '22'
ORDER BY `ulp_user_id_to` DESC
 LIMIT 5
ERROR - 2020-10-25 08:01:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php:270) /home2/matrimonyapp/public_html/demo/system/core/Common.php 564
ERROR - 2020-10-25 08:01:33 --> Severity: Error --> Call to a member function result() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 270
ERROR - 2020-10-25 08:02:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:02:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:02:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:02:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:02:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:02:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:02:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:02:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:02:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:02:39 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:03:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:03:23 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:03:42 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:04:14 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-25 08:04:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:04:39 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 38
ERROR - 2020-10-25 08:04:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:05:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:07:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:07:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:07:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 08:11:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:12:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:12:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:12:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:12:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 08:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:22:20 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:25:03 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 08:56:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:56:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:56:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 08:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:58:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 08:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 08:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:45:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:45:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:45:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 09:45:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:45:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:56:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: DELETE FROM ma_user_liked_profiles WHERE ulp_id=
ERROR - 2020-10-25 09:56:59 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 163
ERROR - 2020-10-25 09:58:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:58:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:59:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 09:59:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:59:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:59:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:59:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:59:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 09:59:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 09:59:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:02:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:02:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:02:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 10:02:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:02:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:05:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:05:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:05:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 10:05:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:05:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:14:15 --> 404 Page Not Found: Service-info/index
ERROR - 2020-10-25 10:31:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:31:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:31:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 10:32:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:32:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:32:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 10:32:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:32:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:34:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 10:43:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:43:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 10:43:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:46:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:46:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:46:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 10:46:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:46:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:46:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:46:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:46:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 10:46:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 10:46:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 12:15:36 --> 404 Page Not Found: Sendemail/index
ERROR - 2020-10-25 12:16:01 --> Severity: Error --> Call to undefined function sendemailtoall() /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 493
ERROR - 2020-10-25 13:31:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 13:31:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 13:31:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 13:31:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 13:31:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 13:31:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 13:31:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-25 13:31:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 13:31:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 13:31:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-25 16:35:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-25 16:35:43 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-25 16:35:43 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-25 16:35:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 16:35:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 16:36:09 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 16:36:14 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-25 16:36:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 16:36:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-25 16:36:29 --> 404 Page Not Found: admin/Common/skin-config.html

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-24 02:50:53 --> Severity: Warning --> mysqli::query(): Empty query /home2/matrimonyapp/public_html/demo/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2020-10-24 02:50:53 --> Query error:  - Invalid query: 
ERROR - 2020-10-24 02:50:53 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-24 03:17:23 --> Severity: Notice --> Undefined variable: typeoflist /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 300
ERROR - 2020-10-24 03:17:23 --> Severity: Notice --> Undefined variable: sql /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-24 03:17:23 --> Severity: Warning --> mysqli::query(): Empty query /home2/matrimonyapp/public_html/demo/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2020-10-24 03:17:23 --> Query error:  - Invalid query: 
ERROR - 2020-10-24 03:17:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/matrimonyapp/public_html/demo/system/core/Exceptions.php:271) /home2/matrimonyapp/public_html/demo/system/core/Common.php 564
ERROR - 2020-10-24 03:17:23 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-24 03:18:37 --> Severity: Notice --> Undefined variable: typeoflist /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 300
ERROR - 2020-10-24 03:18:37 --> Severity: Notice --> Undefined variable: sql /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-24 03:18:37 --> Severity: Warning --> mysqli::query(): Empty query /home2/matrimonyapp/public_html/demo/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2020-10-24 03:18:37 --> Query error:  - Invalid query: 
ERROR - 2020-10-24 03:18:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/matrimonyapp/public_html/demo/system/core/Exceptions.php:271) /home2/matrimonyapp/public_html/demo/system/core/Common.php 564
ERROR - 2020-10-24 03:18:37 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-24 03:19:56 --> Severity: Notice --> Undefined variable: sql /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-24 03:19:56 --> Severity: Warning --> mysqli::query(): Empty query /home2/matrimonyapp/public_html/demo/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2020-10-24 03:19:56 --> Query error:  - Invalid query: 
ERROR - 2020-10-24 03:19:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/matrimonyapp/public_html/demo/system/core/Exceptions.php:271) /home2/matrimonyapp/public_html/demo/system/core/Common.php 564
ERROR - 2020-10-24 03:19:56 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 254
ERROR - 2020-10-24 03:21:33 --> Severity: Notice --> Undefined variable: typeoflist /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 340
ERROR - 2020-10-24 03:21:33 --> Severity: Notice --> Undefined variable: displaynonef /home2/matrimonyapp/public_html/demo/application/views/services.php 46
ERROR - 2020-10-24 03:26:28 --> Severity: Notice --> Undefined variable: servicemasterid /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 305
ERROR - 2020-10-24 03:26:28 --> Severity: Notice --> Undefined variable: servicemasterid /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 305
ERROR - 2020-10-24 03:26:28 --> Severity: Notice --> Undefined variable: typeoflist /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 345
ERROR - 2020-10-24 03:26:28 --> Severity: Notice --> Undefined variable: servicemasterid /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 351
ERROR - 2020-10-24 03:26:28 --> Severity: Notice --> Undefined variable: displaynonef /home2/matrimonyapp/public_html/demo/application/views/services.php 46
ERROR - 2020-10-24 03:27:02 --> Severity: Notice --> Undefined variable: typeoflist /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 346
ERROR - 2020-10-24 03:27:02 --> Severity: Notice --> Undefined variable: displaynonef /home2/matrimonyapp/public_html/demo/application/views/services.php 46
ERROR - 2020-10-24 03:27:45 --> Severity: Notice --> Undefined variable: typeoflist /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 346
ERROR - 2020-10-24 03:27:45 --> Severity: Notice --> Undefined variable: displaynonef /home2/matrimonyapp/public_html/demo/application/views/services.php 46
ERROR - 2020-10-24 03:28:13 --> Severity: Notice --> Undefined variable: displaynonef /home2/matrimonyapp/public_html/demo/application/views/services.php 46
ERROR - 2020-10-24 12:24:17 --> Severity: Parsing Error --> syntax error, unexpected '!' /home2/matrimonyapp/public_html/demo/application/views/index.php 538
ERROR - 2020-10-24 12:24:20 --> Severity: Parsing Error --> syntax error, unexpected '!' /home2/matrimonyapp/public_html/demo/application/views/index.php 538
ERROR - 2020-10-24 12:24:34 --> Severity: Parsing Error --> syntax error, unexpected '!' /home2/matrimonyapp/public_html/demo/application/views/index.php 538
ERROR - 2020-10-24 12:24:58 --> Severity: Parsing Error --> syntax error, unexpected '!' /home2/matrimonyapp/public_html/demo/application/views/index.php 538
ERROR - 2020-10-24 12:25:15 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:25:15 --> Severity: Parsing Error --> syntax error, unexpected '!' /home2/matrimonyapp/public_html/demo/application/views/index.php 538
ERROR - 2020-10-24 12:25:36 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:31:42 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:32:17 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:32:22 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:33:00 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:34:03 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:34:21 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:34:41 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:35:28 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:35:31 --> Severity: Notice --> Undefined variable: page_title /home2/matrimonyapp/public_html/demo/application/views/includes/header.php 42
ERROR - 2020-10-24 12:50:13 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/matrimonyapp/public_html/demo/application/views/index.php 288
ERROR - 2020-10-24 12:54:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 12:54:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 12:54:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 12:55:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 12:55:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 12:55:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 12:55:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 12:55:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:07:36 --> 404 Page Not Found: Serviceslist/index
ERROR - 2020-10-24 13:25:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-24 13:35:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:35:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 13:35:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:35:21 --> 404 Page Not Found: Serviceslist/index
ERROR - 2020-10-24 13:37:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 13:37:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:37:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:37:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:37:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:42:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:42:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:42:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 13:43:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 13:43:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:43:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:43:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:43:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:45:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 13:45:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:45:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:45:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:45:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:45:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 13:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 13:58:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-24 14:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:03:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:06:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:06:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:06:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:06:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:06:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:07:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:07:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:07:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:07:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:08:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:08:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:08:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:08:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:08:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:14:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:14:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:14:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:14:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:14:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:14:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:14:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:14:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:14:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:14:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:14:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:15:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:15:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:15:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:15:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:15:15 --> Severity: Error --> Call to undefined method Common_model::getSubscribeDetails() /home2/matrimonyapp/public_html/demo/application/controllers/User.php 14
ERROR - 2020-10-24 14:16:33 --> Query error: Unknown column 'ma_users.user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_subscribers`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `sbemail` = 'dileepkumaronda@gmail.com'
AND `sbstatus` = 1
ERROR - 2020-10-24 14:16:33 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 284
ERROR - 2020-10-24 14:16:36 --> Query error: Unknown column 'ma_users.user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_subscribers`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `sbemail` = 'dileepkumaronda@gmail.com'
AND `sbstatus` = 1
ERROR - 2020-10-24 14:16:36 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 284
ERROR - 2020-10-24 14:16:55 --> Query error: Unknown column 'ma_users.user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_subscribers`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `sbemail` = 'dileepkumaronda@gmail.com'
AND `sbstatus` = 1
ERROR - 2020-10-24 14:16:55 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 284
ERROR - 2020-10-24 14:17:23 --> Query error: Unknown column 'ma_users.user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_subscribers`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `sbemail` = 'dileepkumaronda@gmail.com'
AND `sbstatus` = 1
ERROR - 2020-10-24 14:17:23 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 284
ERROR - 2020-10-24 14:20:22 --> Query error: Unknown column 'ma_users.user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_subscribers`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `sbemail` = 'dileepkumaronda@gmail.com'
AND `sbstatus` = 1
ERROR - 2020-10-24 14:20:22 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 284
ERROR - 2020-10-24 14:30:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:30:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:30:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:30:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:30:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:31:12 --> Query error: Unknown column 'ma_users.user_id' in 'on clause' - Invalid query: SELECT *
FROM `ma_subscribers`
LEFT JOIN `ma_user_personal_info` ON `ma_user_personal_info`.`upi_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_restricted_details` ON `ma_user_restricted_details`.`urd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_educational_details` ON `ma_user_educational_details`.`ued_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_family_details` ON `ma_user_family_details`.`upd_user_id` = `ma_users`.`user_id`
LEFT JOIN `ma_user_partner_prefered_details` ON `ma_user_partner_prefered_details`.`uppd_user_id` = `ma_users`.`user_id`
WHERE `sbemail` = 'dileepkumarkonda@gmail.com'
AND `sbstatus` = 1
ERROR - 2020-10-24 14:31:12 --> Severity: Error --> Call to a member function row() on a non-object /home2/matrimonyapp/public_html/demo/application/models/admin/Common_model.php 284
ERROR - 2020-10-24 14:35:02 --> Severity: Notice --> Undefined variable: sbid /home2/matrimonyapp/public_html/demo/application/controllers/User.php 24
ERROR - 2020-10-24 14:39:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:39:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:39:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:39:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:39:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:41:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:41:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:41:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:41:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:41:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:41:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:41:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:41:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:41:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:41:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:55:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 14:55:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:55:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 14:57:49 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-24 15:00:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-24 16:22:51 --> Severity: Parsing Error --> syntax error, unexpected end of file /home2/matrimonyapp/public_html/demo/application/controllers/LoaddingPage.php 466
ERROR - 2020-10-24 16:30:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:30:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:30:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 16:31:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 16:31:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 16:31:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 16:31:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:31:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:34:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 16:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:35:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:35:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:35:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 16:35:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:35:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 16:35:07 --> 404 Page Not Found: User/profileLikedorDisliked
ERROR - 2020-10-24 17:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 17:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 17:19:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 17:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 17:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 17:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 17:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 17:19:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-24 17:19:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-24 17:19:58 --> 404 Page Not Found: Assets/js

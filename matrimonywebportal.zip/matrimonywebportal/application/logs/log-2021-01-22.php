<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-22 05:30:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:30:56 --> Unable to connect to the database
ERROR - 2021-01-22 05:30:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:30:56 --> Unable to connect to the database
ERROR - 2021-01-22 05:30:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:30:56 --> Unable to connect to the database
ERROR - 2021-01-22 05:30:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:30:56 --> Unable to connect to the database
ERROR - 2021-01-22 05:30:56 --> Query error: Unknown database 'nayeebraweb_db' - Invalid query: SELECT *
FROM `ma_success_stories`
WHERE `ssstatus` = 1
ORDER BY `ssid` DESC
ERROR - 2021-01-22 05:30:56 --> Severity: error --> Exception: Call to a member function result() on bool E:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 28
ERROR - 2021-01-22 05:31:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:31:04 --> Unable to connect to the database
ERROR - 2021-01-22 05:31:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:31:04 --> Unable to connect to the database
ERROR - 2021-01-22 05:31:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:31:04 --> Unable to connect to the database
ERROR - 2021-01-22 05:31:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:31:04 --> Unable to connect to the database
ERROR - 2021-01-22 05:31:04 --> Query error: Unknown database 'nayeebraweb_db' - Invalid query: SELECT *
FROM `ma_success_stories`
WHERE `ssstatus` = 1
ORDER BY `ssid` DESC
ERROR - 2021-01-22 05:31:04 --> Severity: error --> Exception: Call to a member function result() on bool E:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 28
ERROR - 2021-01-22 05:31:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:31:34 --> Unable to connect to the database
ERROR - 2021-01-22 05:31:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:31:34 --> Unable to connect to the database
ERROR - 2021-01-22 05:31:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:31:34 --> Unable to connect to the database
ERROR - 2021-01-22 05:31:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:31:34 --> Unable to connect to the database
ERROR - 2021-01-22 05:31:34 --> Query error: Unknown database 'nayeebraweb_db' - Invalid query: SELECT *
FROM `ma_success_stories`
WHERE `ssstatus` = 1
ORDER BY `ssid` DESC
ERROR - 2021-01-22 05:31:34 --> Severity: error --> Exception: Call to a member function result() on bool E:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 28
ERROR - 2021-01-22 05:46:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:46:19 --> Unable to connect to the database
ERROR - 2021-01-22 05:46:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:46:19 --> Unable to connect to the database
ERROR - 2021-01-22 05:46:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:46:19 --> Unable to connect to the database
ERROR - 2021-01-22 05:46:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:46:19 --> Unable to connect to the database
ERROR - 2021-01-22 05:46:19 --> Query error: Unknown database 'nayeebraweb_db' - Invalid query: SELECT *
FROM `ma_success_stories`
WHERE `ssstatus` = 1
ORDER BY `ssid` DESC
ERROR - 2021-01-22 05:46:19 --> Severity: error --> Exception: Call to a member function result() on bool E:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 28
ERROR - 2021-01-22 05:48:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:48:04 --> Unable to connect to the database
ERROR - 2021-01-22 05:48:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:48:04 --> Unable to connect to the database
ERROR - 2021-01-22 05:48:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:48:04 --> Unable to connect to the database
ERROR - 2021-01-22 05:48:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:48:04 --> Unable to connect to the database
ERROR - 2021-01-22 05:48:04 --> Query error: Unknown database 'nayeebraweb_db' - Invalid query: SELECT *
FROM `ma_success_stories`
WHERE `ssstatus` = 1
ORDER BY `ssid` DESC
ERROR - 2021-01-22 05:48:04 --> Severity: error --> Exception: Call to a member function result() on bool E:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 28
ERROR - 2021-01-22 05:48:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:48:41 --> Unable to connect to the database
ERROR - 2021-01-22 05:48:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:48:41 --> Unable to connect to the database
ERROR - 2021-01-22 05:48:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:48:41 --> Unable to connect to the database
ERROR - 2021-01-22 05:48:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nayeebraweb_db' E:\xampp\htdocs\matrimonywebportal\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-01-22 05:48:41 --> Unable to connect to the database
ERROR - 2021-01-22 05:48:41 --> Query error: Unknown database 'nayeebraweb_db' - Invalid query: SELECT *
FROM `ma_success_stories`
WHERE `ssstatus` = 1
ORDER BY `ssid` DESC
ERROR - 2021-01-22 05:48:41 --> Severity: error --> Exception: Call to a member function result() on bool E:\xampp\htdocs\matrimonywebportal\application\models\admin\Common_model.php 28

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-02 03:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-02 04:18:51 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-12-02 04:18:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-12-02 04:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-02 05:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-02 11:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-02 18:40:05 --> 404 Page Not Found: Robotstxt/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-20 05:23:06 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-09-20 05:23:09 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 05:23:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 05:24:30 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 05:24:32 --> 404 Page Not Found: admin/Settings/serviceslist
ERROR - 2020-09-20 05:24:45 --> 404 Page Not Found: admin/Settings/serviceslist
ERROR - 2020-09-20 05:25:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 05:25:43 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 05:26:39 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 05:26:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 05:26:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 10:44:00 --> Severity: Compile Error --> Cannot redeclare Common::addservice() D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 134
ERROR - 2020-09-20 10:44:08 --> Severity: Compile Error --> Cannot redeclare Common::addservice() D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 134
ERROR - 2020-09-20 10:44:20 --> Severity: Compile Error --> Cannot redeclare Common::addservice() D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 134
ERROR - 2020-09-20 10:44:32 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-09-20 10:44:35 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 10:44:36 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 10:44:37 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 10:44:38 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 10:44:38 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 10:44:40 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 10:44:41 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 10:44:42 --> Severity: Compile Error --> Cannot redeclare Common::addservice() D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 134
ERROR - 2020-09-20 10:47:12 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 10:47:19 --> 404 Page Not Found: admin/Common/bannerslist
ERROR - 2020-09-20 10:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\bannerslist.php 39
ERROR - 2020-09-20 10:51:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 10:52:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\bannerslist.php 39
ERROR - 2020-09-20 10:52:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 10:52:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 10:53:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 10:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\bannerslist.php 39
ERROR - 2020-09-20 10:53:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:00:29 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:02:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\matrimonyapp\application\views\admin\bannerslist.php 39
ERROR - 2020-09-20 11:02:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:03:18 --> 404 Page Not Found: Bannerspic/mob_20092020110256banner.jpg
ERROR - 2020-09-20 11:03:18 --> 404 Page Not Found: Bannerspic/20092020110256banner.jpg
ERROR - 2020-09-20 11:03:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:04:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:04:23 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:04:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:04:31 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:04:33 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:04:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:04:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:05:43 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-09-20 11:05:44 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 11:05:50 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 11:05:51 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 11:05:59 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 11:06:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 12:53:12 --> 404 Page Not Found: /index
ERROR - 2020-09-20 12:53:41 --> 404 Page Not Found: /index
ERROR - 2020-09-20 12:54:30 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-09-20 12:54:33 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:54:35 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:54:37 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:54:42 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:54:44 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:54:46 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:54:48 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:54:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 12:54:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 12:55:00 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:55:05 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:55:06 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:55:07 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:55:08 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:55:08 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:55:10 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-09-20 12:55:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 12:55:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-09-20 12:55:17 --> 404 Page Not Found: admin/Settings/skin-config.html

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-06 03:38:09 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-06 03:38:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-06 04:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-06 08:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-06 15:24:43 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-06 15:24:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-06 17:40:16 --> 404 Page Not Found: Wp-1ogin_bakphp/index
ERROR - 2020-11-06 17:40:16 --> 404 Page Not Found: Accessonphp/index
ERROR - 2020-11-06 17:40:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-06 17:40:17 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2020-11-06 17:40:17 --> 404 Page Not Found: Wp-xmlrpcphp/index
ERROR - 2020-11-06 17:40:17 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2020-11-06 17:40:17 --> 404 Page Not Found: Upsphp/index
ERROR - 2020-11-06 17:40:18 --> 404 Page Not Found: Phpmyadmin/url.php
ERROR - 2020-11-06 19:40:44 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-06 19:40:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-06 20:24:05 --> 404 Page Not Found: Login/index
ERROR - 2020-11-06 22:20:05 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-06 22:52:30 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-06 22:52:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-06 23:55:21 --> 404 Page Not Found: Wp-content/plugins

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-10 10:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-10 12:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-10 14:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-10 15:08:15 --> 404 Page Not Found: Faviconico/index

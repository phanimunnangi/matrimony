<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-10 01:49:22 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-10 05:48:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-11-10 07:29:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-11-10 09:57:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-11-10 11:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-10 21:51:30 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-10 21:51:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-10 23:41:26 --> 404 Page Not Found: Robotstxt/index

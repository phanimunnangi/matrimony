<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-08 09:25:44 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-11-08 09:25:44 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-11-08 13:17:50 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-11-08 20:34:14 --> 404 Page Not Found: Robotstxt/index

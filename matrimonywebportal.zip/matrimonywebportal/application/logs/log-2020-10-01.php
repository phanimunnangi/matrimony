<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-01 07:01:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-01 10:28:59 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-01 10:28:59 --> 404 Page Not Found: Logo_icon_150x150_RZ4_iconico/index
ERROR - 2020-10-01 10:29:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 10:29:26 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 10:50:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 10:50:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 10:57:44 --> Severity: error --> Exception: syntax error, unexpected '$page' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\views\admin\includes\header.php 62
ERROR - 2020-10-01 10:57:47 --> Severity: error --> Exception: syntax error, unexpected '$page' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\views\admin\includes\header.php 62
ERROR - 2020-10-01 10:57:53 --> Severity: error --> Exception: syntax error, unexpected '$page' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\views\admin\includes\header.php 62
ERROR - 2020-10-01 10:57:55 --> Severity: error --> Exception: syntax error, unexpected '$page' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\views\admin\includes\header.php 62
ERROR - 2020-10-01 10:58:02 --> Severity: error --> Exception: syntax error, unexpected '$page' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\views\admin\includes\header.php 62
ERROR - 2020-10-01 10:59:07 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-01 10:59:09 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 10:59:23 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-01 10:59:24 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-01 10:59:26 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-01 10:59:32 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-01 10:59:34 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-01 10:59:35 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-01 10:59:41 --> 404 Page Not Found: admin/Settings/skin-config.html
ERROR - 2020-10-01 10:59:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 10:59:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 11:10:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 11:10:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 11:11:09 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 11:18:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 12:10:28 --> 404 Page Not Found: Userservicepics/index
ERROR - 2020-10-01 12:10:28 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 12:12:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 12:13:23 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:10:04 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:10:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:10:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:10:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:10:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:10:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:10:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:11:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:11:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 13:11:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 14:11:33 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 14:11:47 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 14:12:51 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 14:12:57 --> 404 Page Not Found: admin/Skin-confightml/index
ERROR - 2020-10-01 15:31:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 15:32:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 15:34:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 15:35:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 15:57:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 15:57:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 15:59:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 16:00:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 16:02:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:17:25 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:17:27 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:18:00 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:18:03 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:18:03 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:18:08 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:18:08 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:18:08 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:18:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:18:13 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:18:13 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:18:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:18:15 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:18:15 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:18:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:18:16 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:18:17 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:18:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:18:17 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:18:17 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:18:18 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:18:18 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:18:18 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:18:23 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:18:23 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:18:23 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:19:12 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:19:12 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:13 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:19:14 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:19:14 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:19:14 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:15 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:19:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:19:15 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:15 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:19:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:19:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:19:16 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:16 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:19:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:19:16 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:16 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:19:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:19:17 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:17 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:19:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:19:18 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:18 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:19:18 --> 404 Page Not Found: Admin_assets/js
ERROR - 2020-10-01 17:19:18 --> 404 Page Not Found: Admin_assets/css
ERROR - 2020-10-01 17:20:26 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:21:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:21:30 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:22:29 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:22:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:27:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:27:48 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:29:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:30:14 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:31:39 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:34:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:34:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:35:02 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:35:07 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:35:35 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:36:56 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:37:20 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:37:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:38:30 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:39:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:39:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:40:31 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:40:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:41:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:41:50 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:43:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:45:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:47:28 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 17:57:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 18:55:10 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 18:55:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 18:55:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 18:57:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 18:57:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 18:57:17 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 18:57:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 18:59:12 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 19:37:33 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:37:34 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:38:07 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:38:08 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:38:08 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:38:08 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:38:08 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:38:09 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:38:57 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 299
ERROR - 2020-10-01 19:38:59 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 299
ERROR - 2020-10-01 19:39:13 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 299
ERROR - 2020-10-01 19:39:13 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 299
ERROR - 2020-10-01 19:39:13 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 299
ERROR - 2020-10-01 19:39:14 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 299
ERROR - 2020-10-01 19:39:14 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 299
ERROR - 2020-10-01 19:39:14 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 299
ERROR - 2020-10-01 19:39:14 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 299
ERROR - 2020-10-01 19:40:20 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:40:22 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:40:23 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:40:23 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 288
ERROR - 2020-10-01 19:42:27 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:42:27 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:42:28 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:42:28 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:43:55 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:50:39 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 19:51:49 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:52:17 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:52:18 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:52:18 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:52:18 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:52:27 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 19:53:07 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:53:25 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 291
ERROR - 2020-10-01 19:53:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 19:55:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 19:59:27 --> Severity: Notice --> Undefined variable: servicewebsite D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 361
ERROR - 2020-10-01 20:04:15 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:06:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:06:35 --> 404 Page Not Found: admin/Userserviceslist/index
ERROR - 2020-10-01 20:06:51 --> 404 Page Not Found: admin/Userserviceslist/index
ERROR - 2020-10-01 20:07:16 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:07:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:07:22 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:07:29 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:10:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:12:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:12:45 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:12:48 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:12:51 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:12:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:12:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:14:34 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:15:20 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:15:24 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:23:01 --> Severity: error --> Exception: syntax error, unexpected '$sid' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 246
ERROR - 2020-10-01 20:24:01 --> Severity: error --> Exception: syntax error, unexpected '$sid' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 246
ERROR - 2020-10-01 20:24:48 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 250
ERROR - 2020-10-01 20:24:53 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 252
ERROR - 2020-10-01 20:24:54 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\matrimonyapp\application\controllers\admin\Common.php 252
ERROR - 2020-10-01 20:25:24 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:25:39 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:25:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:26:37 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:26:39 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:26:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:26:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:26:51 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:26:53 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:26:55 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:26:57 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:27:01 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:27:19 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:27:40 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:27:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:27:41 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:27:44 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:27:46 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:27:49 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:28:05 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:28:06 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:28:11 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:28:54 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:28:56 --> Query error: Unknown column 'servicedisplayid' in 'where clause' - Invalid query: SELECT *
FROM `ma_servicemaster`
WHERE `servicedisplayid` = 'USERSERVICE2001'
ERROR - 2020-10-01 20:28:56 --> Severity: error --> Exception: Call to a member function row() on boolean D:\xampp\htdocs\matrimonyapp\application\models\admin\Common_model.php 57
ERROR - 2020-10-01 20:32:21 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:32:52 --> 404 Page Not Found: admin/Common/skin-config.html
ERROR - 2020-10-01 20:33:14 --> 404 Page Not Found: admin/Common/skin-config.html

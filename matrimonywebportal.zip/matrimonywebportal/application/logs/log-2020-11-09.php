<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-09 00:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-09 03:43:22 --> 404 Page Not Found: Member/matrimony_register
ERROR - 2020-11-09 08:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-09 17:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-09 17:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-09 20:59:41 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-09 20:59:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-09 22:17:46 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-09 22:17:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564
ERROR - 2020-11-09 22:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-11-09 23:52:48 --> Severity: Notice --> Undefined variable: reported /home2/nayeebrahmincomm/public_html/application/helpers/common_helper.php 49
ERROR - 2020-11-09 23:52:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home2/nayeebrahmincomm/public_html/system/core/Exceptions.php:271) /home2/nayeebrahmincomm/public_html/system/helpers/url_helper.php 564

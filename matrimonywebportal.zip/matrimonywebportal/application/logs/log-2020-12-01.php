<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-01 02:42:01 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-12-01 07:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-01 07:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-01 08:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-01 11:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-01 11:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-12-01 16:03:05 --> 404 Page Not Found: App/etc
ERROR - 2020-12-01 16:03:26 --> 404 Page Not Found: Js/webforms
ERROR - 2020-12-01 16:03:37 --> 404 Page Not Found: Magmi/web
ERROR - 2020-12-01 19:56:47 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-12-01 19:56:48 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-12-01 19:56:48 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-12-01 19:56:49 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-12-01 19:56:50 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-12-01 19:56:51 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-12-01 19:56:52 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-12-01 19:56:53 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-12-01 19:56:54 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-12-01 19:56:55 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-12-01 19:56:55 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2020-12-01 19:56:56 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-12-01 19:56:56 --> 404 Page Not Found: Media/wp-includes
ERROR - 2020-12-01 19:56:57 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-12-01 19:56:58 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-12-01 19:56:59 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-12-01 19:56:59 --> 404 Page Not Found: Sito/wp-includes
